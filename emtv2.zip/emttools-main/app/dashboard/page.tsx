
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

function getTodayLocalDate() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

type Incident = {
  id: string;
  incident_name: string;
  incident_type: string | null;
  location: string | null;
  incident_date: string | null;
  incident_time?: string | null;
  fire_type: string | null;
  description: string | null;
  status: string;
  created_at: string;
};

async function emtApi(
  method: "GET" | "POST" | "PATCH" | "DELETE",
  body?: unknown
) {
  const response = await fetch("/api/incidents", {
    method,
    headers: { "Content-Type": "application/json" },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    cache: "no-store",
  });

  let result: any = {};
  try { result = await response.json(); } catch {}

  if (!response.ok) {
    throw new Error(result.error || `Request failed (${response.status}).`);
  }

  return result;
}

export default function DashboardPage() {
  const router = useRouter();

  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [editingIncident, setEditingIncident] = useState(false);
  const [editNotice, setEditNotice] = useState("");
  const [search, setSearch] = useState("");
  const [incidentName, setIncidentName] = useState("");
  const [incidentType, setIncidentType] = useState("");
  const [location, setLocation] = useState("");
  const [fireType, setFireType] = useState("Real");
  const [incidentDate, setIncidentDate] = useState("");
  const [incidentTime, setIncidentTime] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [filterDate, setFilterDate] = useState("");
  const [sortOrder, setSortOrder] = useState("newest");
  const [page, setPage] = useState(1);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pageSize = 6;

  // Load incidents from Supabase. Existing localStorage data is left untouched.
  useEffect(() => {
    setIncidentDate(getTodayLocalDate());
    void refreshIncidents();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function clearForm() {
    setIncidentName("");
    setIncidentType("");
    setLocation("");
    setFireType("Real");
    setIncidentDate(getTodayLocalDate());
    setIncidentTime("");
    setDescription("");
    setError("");
    setNotice("");
  }

  async function createIncident(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setNotice("");

    if (!incidentName.trim() || !incidentType || !location.trim() || !fireType || !incidentDate) {
      setError("Please complete all required fields.");
      return;
    }

    setSaving(true);
    const incident: Incident = {
      id: typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `INC-${Date.now()}`,
      incident_name: incidentName.trim(),
      incident_type: incidentType,
      location: location.trim(),
      incident_date: incidentDate,
      incident_time: incidentTime || null,
      fire_type: fireType,
      description: description.trim() || null,
      status: "Active",
      created_at: new Date().toISOString(),
    };

    try {
      const savedIncident = await emtApi("POST", incident) as Incident;

      setIncidents((current) => [savedIncident, ...current.filter((item) => item.id !== savedIncident.id)]);
      clearForm();
      setPage(1);
      setNotice("Incident created successfully.");

      // Open the Incident page focused on the database-saved incident.
      router.push(`/incident?incidentId=${encodeURIComponent(savedIncident.id)}`);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to create incident.");
    } finally {
      setSaving(false);
    }
  }

  async function deleteIncident(incident: Incident) {
    const confirmed = window.confirm(
      `Delete incident "${incident.incident_name}"?`
    );
    if (!confirmed) return;

    setError("");
    setNotice("");

    try {
      await emtApi("DELETE", { id: incident.id });

      setIncidents((current) => current.filter((item) => item.id !== incident.id));
      if (selectedIncident?.id === incident.id) {
        setSelectedIncident(null);
        setEditingIncident(false);
      }
      setNotice("Incident deleted successfully.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to delete incident.");
    }
  }

  async function refreshIncidents() {
    setLoading(true);
    try {
      const result = await emtApi("GET");
      setIncidents((Array.isArray(result) ? result : result.incidents ?? []) as Incident[]);
      setError("");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to read incident records.");
    } finally {
      setLoading(false);
    }
  }

  const filteredIncidents = incidents
    .filter((incident) => {
      const term = search.trim().toLowerCase();

      const matchesSearch =
        !term ||
        incident.incident_name.toLowerCase().includes(term) ||
        (incident.location ?? "").toLowerCase().includes(term);

      const matchesDate =
        !filterDate || incident.incident_date === filterDate;

      return matchesSearch && matchesDate;
    })
    .sort((a, b) => {
      const aDate = new Date(a.created_at).getTime();
      const bDate = new Date(b.created_at).getTime();

      return sortOrder === "newest" ? bDate - aDate : aDate - bDate;
    });

  const totalPages = Math.max(
    1,
    Math.ceil(filteredIncidents.length / pageSize)
  );

  const visibleIncidents = filteredIncidents.slice(
    (page - 1) * pageSize,
    page * pageSize
  );

  function formatDate(value: string | null) {
    if (!value) return "—";

    return new Date(`${value.slice(0, 10)}T00:00:00`).toLocaleDateString(
      "en-GB",
      { day: "2-digit", month: "short", year: "numeric" }
    );
  }

  function formatDateTime(value: string) {
    return new Date(value).toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  return (
    <main className="min-h-screen bg-[#edf4fc] text-slate-800">
      <div className="flex min-h-screen">
        {/* MOBILE MENU OVERLAY: only visible on small screens */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 flex md:hidden">
            <button
              type="button"
              aria-label="Close navigation menu"
              className="absolute inset-0 bg-slate-950/60"
              onClick={() => setMobileMenuOpen(false)}
            />
            <aside className="relative z-10 flex min-h-screen w-[280px] max-w-[85vw] shrink-0 flex-col bg-[#102f50] p-5 text-white shadow-2xl">
              <div className="flex items-start justify-between gap-3 border-b border-white/10 pb-6">
                <div>
                  <h1 className="text-lg font-extrabold tracking-wide">🛡️ EMT SYSTEM</h1>
                  <p className="mt-1 text-xs text-blue-200">Emergency Management Team</p>
                </div>
                <button
                  type="button"
                  aria-label="Close navigation menu"
                  onClick={() => setMobileMenuOpen(false)}
                  className="rounded-lg px-3 py-1 text-2xl leading-none text-white hover:bg-white/10"
                >
                  ×
                </button>
              </div>

              <nav className="mt-7 space-y-1">
                <button type="button" onClick={() => { setMobileMenuOpen(false); router.push("/dashboard"); }} className="w-full rounded-lg bg-blue-500 px-3 py-3 text-left text-sm font-semibold text-white hover:bg-blue-600">▦　Dashboard</button>
                <button type="button" onClick={() => { setMobileMenuOpen(false); router.push("/incident"); }} className="w-full rounded-lg px-3 py-3 text-left text-sm text-blue-100 transition hover:bg-white/10">▤　Incidents</button>
                <button type="button" onClick={() => { setMobileMenuOpen(false); router.push("/chronology"); }} className="w-full rounded-lg px-3 py-3 text-left text-sm text-blue-100 transition hover:bg-white/10">◷　Chronology</button>
                <button type="button" onClick={() => { setMobileMenuOpen(false); router.push("/ipstatus"); }} className="w-full rounded-lg px-3 py-3 text-left text-sm text-blue-100 transition hover:bg-white/10">▣　IP Status</button>
                <button type="button" onClick={() => { setMobileMenuOpen(false); router.push("/pear"); }} className="w-full rounded-lg px-3 py-3 text-left text-sm text-blue-100 transition hover:bg-white/10">♧　PEAR</button>
              </nav>

              <div className="mt-auto px-1 pt-10 text-center text-[9px] font-semibold tracking-widest text-blue-200">
                SAFE · PREPARE · RESPOND · RECOVER
                <p className="mt-4 text-xs font-medium leading-relaxed normal-case tracking-normal text-white">Better Prepared,<br />Safer Tomorrow</p>
              </div>
            </aside>
          </div>
        )}

        {/* DESKTOP SIDEBAR: original design preserved */}
        <aside className="hidden min-h-screen w-[248px] shrink-0 flex-col bg-[#102f50] p-5 text-white md:flex">
          <div className="border-b border-white/10 pb-6">
            <h1 className="text-lg font-extrabold tracking-wide">🛡️ EMT SYSTEM</h1>
            <p className="mt-1 text-xs text-blue-200">
              Emergency Management Team
            </p>
          </div>

          <nav className="mt-7 space-y-1">
            <button
              type="button"
              onClick={() => router.push("/dashboard")}
              className="w-full rounded-lg bg-blue-500 px-3 py-3 text-left text-sm font-semibold text-white hover:bg-blue-600"
            >
              ▦　Dashboard
            </button>

            <button
              onClick={() => router.push("/incident")}
              className="w-full rounded-lg px-3 py-3 text-left text-sm text-blue-100 transition hover:bg-white/10"
            >
              ▤　Incidents
            </button>

            <button
              onClick={() => router.push("/chronology")}
              className="w-full rounded-lg px-3 py-3 text-left text-sm text-blue-100 transition hover:bg-white/10"
            >
              ◷　Chronology
            </button>

            <button
              onClick={() => router.push("/ipstatus")}
              className="w-full rounded-lg px-3 py-3 text-left text-sm text-blue-100 transition hover:bg-white/10"
            >
              ▣　IP Status
            </button>

            <button
              onClick={() => router.push("/pear")}
              className="w-full rounded-lg px-3 py-3 text-left text-sm text-blue-100 transition hover:bg-white/10"
            >
              ♧　PEAR
            </button>
          </nav>

          <div className="mt-auto px-1 pt-10 text-center text-[9px] font-semibold tracking-widest text-blue-200">
            SAFE · PREPARE · RESPOND · RECOVER
            <p className="mt-4 text-xs font-medium leading-relaxed normal-case tracking-normal text-white">
              Better Prepared,
              <br />
              Safer Tomorrow
            </p>
          </div>
        </aside>

        {/* MAIN CONTENT */}
        <section className="min-w-0 flex-1">
          <header className="flex min-h-[76px] flex-wrap items-center justify-between gap-3 border-b border-blue-100 bg-gradient-to-r from-blue-50 via-sky-100 to-white px-5 py-4 sm:px-8">
            <div className="flex min-w-0 items-start gap-3">
              <button
                type="button"
                aria-label="Open navigation menu"
                aria-expanded={mobileMenuOpen}
                onClick={() => setMobileMenuOpen(true)}
                className="mt-0.5 inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-blue-200 bg-white text-xl text-[#15365f] shadow-sm hover:bg-blue-50 md:hidden"
              >
                ☰
              </button>
              <div className="min-w-0">
              <h1 className="text-xl font-bold text-[#15365f] sm:text-2xl">
                Admin Dashboard
                <span className="ml-2 rounded-full bg-emerald-400 px-2 py-1 text-[10px] text-white">
                  ADMIN
                </span>
              </h1>
              <p className="mt-1 text-sm text-slate-600">
                Welcome to Emergency Management Team (EMT) System
              </p>
              </div>
            </div>

            <div className="rounded-xl border border-blue-100 bg-white px-4 py-3 text-sm font-semibold text-[#17365d]">
              Admin User　⌄
            </div>
          </header>

          <div className="space-y-5 p-4 sm:p-7">
            {/* CREATE INCIDENT */}
            <section className="rounded-xl border border-blue-100 bg-white p-5 shadow-sm sm:p-6">
              <h2 className="mb-4 text-lg font-bold text-[#17365d]">
                <span className="mr-2 text-xl text-blue-600">⊕</span>
                Create New Incident
              </h2>

              <form onSubmit={createIncident}>
                <div className="grid gap-4 lg:grid-cols-4">
                  <label className="text-xs font-bold">
                    Incident Name <span className="text-red-500">*</span>
                    <input
                      required
                      value={incidentName}
                      onChange={(event) => setIncidentName(event.target.value)}
                      placeholder="Enter incident name"
                      className="mt-2 w-full rounded-lg border border-blue-200 bg-white px-3 py-2.5 text-sm font-normal outline-none focus:border-blue-500"
                    />
                  </label>

                  <label className="text-xs font-bold">
                    Type of Incident <span className="text-red-500">*</span>
                    <select
                      required
                      value={incidentType}
                      onChange={(event) => setIncidentType(event.target.value)}
                      className="mt-2 w-full rounded-lg border border-blue-200 bg-white px-3 py-2.5 text-sm font-normal outline-none focus:border-blue-500"
                    >
                      <option value="">Select type</option>
                      <option value="Fire">Fire</option>
                      <option value="Medical">Medical</option>
                      <option value="Rescue">Rescue</option>
                      <option value="HAZMAT">HAZMAT</option>
                      <option value="Drill">Drill</option>
                      <option value="Other">Other</option>
                    </select>
                  </label>

                  <fieldset>
                    <legend className="text-xs font-bold">
                      Fire Type <span className="text-red-500">*</span>
                    </legend>

                    <div className="mt-2 flex gap-2">
                      {["Real", "Drill"].map((type) => (
                        <label
                          key={type}
                          className={`flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-2.5 text-sm ${
                            fireType === type
                              ? "border-blue-300 bg-blue-50 text-blue-700"
                              : "border-blue-100"
                          }`}
                        >
                          <input
                            type="radio"
                            name="fireType"
                            value={type}
                            checked={fireType === type}
                            onChange={() => setFireType(type)}
                            className="accent-blue-600"
                          />
                          {type}
                        </label>
                      ))}
                    </div>
                  </fieldset>

                  <label className="text-xs font-bold">
                    Date <span className="text-red-500">*</span>
                    <input
                      required
                      type="date"
                      value={incidentDate}
                      onChange={(event) => setIncidentDate(event.target.value)}
                      className="mt-2 w-full rounded-lg border border-blue-200 bg-white px-3 py-2.5 text-sm font-normal outline-none focus:border-blue-500"
                    />
                  </label>

                  <label className="text-xs font-bold lg:col-span-4">
                    Location <span className="text-red-500">*</span>
                    <input
                      required
                      value={location}
                      onChange={(event) => setLocation(event.target.value)}
                      placeholder="Enter incident location"
                      className="mt-2 w-full rounded-lg border border-blue-200 bg-white px-3 py-2.5 text-sm font-normal outline-none focus:border-blue-500"
                    />
                  </label>

                  <label className="text-xs font-bold lg:col-span-4">
                    Description (Optional)
                    <textarea
                      rows={2}
                      value={description}
                      onChange={(event) => setDescription(event.target.value)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter" && !event.shiftKey) {
                          event.preventDefault();
                          event.currentTarget.form?.requestSubmit();
                        }
                      }}
                      placeholder="Enter incident description (optional)"
                      className="mt-2 w-full rounded-lg border border-blue-200 bg-white px-3 py-2.5 text-sm font-normal outline-none focus:border-blue-500"
                    />
                  </label>
                </div>

                {error && (
                  <p
                    role="alert"
                    className="mt-3 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700"
                  >
                    {error}
                  </p>
                )}

                {notice && (
                  <p
                    role="status"
                    className="mt-3 rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-700"
                  >
                    {notice}
                  </p>
                )}

                <div className="mt-4 flex flex-wrap justify-end gap-3">
                  <button
                    type="button"
                    onClick={clearForm}
                    className="rounded-lg bg-slate-100 px-5 py-2.5 text-sm font-semibold hover:bg-slate-200"
                  >
                    Clear
                  </button>

                  <button
                    type="submit"
                    disabled={saving}
                    className="rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-blue-700 disabled:opacity-60"
                  >
                    {saving ? "Creating..." : "＋ Create Incident"}
                  </button>
                </div>
              </form>
            </section>

            {/* INCIDENT RECORDS */}
            <section className="rounded-xl border border-blue-100 bg-white p-5 shadow-sm sm:p-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-[#17365d]">
                    ◴　All Incidents
                  </h2>
                  <p className="mt-1 text-xs text-slate-500">
                    {loading
                      ? "Loading records..."
                      : `${filteredIncidents.length} records found`}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="date"
                    aria-label="Filter incidents by date"
                    value={filterDate}
                    onChange={(event) => {
                      setFilterDate(event.target.value);
                      setPage(1);
                    }}
                    className="rounded-lg border border-blue-100 bg-white px-3 py-2 text-xs"
                  />

                  <button
                    type="button"
                    onClick={() => {
                      setFilterDate("");
                      setSearch("");
                      setPage(1);
                    }}
                    className="rounded-lg bg-amber-400 px-3 py-2 text-sm font-bold text-white hover:bg-amber-500"
                    title="Clear filters"
                  >
                    ✕
                  </button>

                  <select
                    value={sortOrder}
                    onChange={(event) => setSortOrder(event.target.value)}
                    className="rounded-lg border border-blue-100 bg-white px-3 py-2 text-xs"
                  >
                    <option value="newest">Latest First</option>
                    <option value="oldest">Oldest First</option>
                  </select>

                  <button
                    type="button"
                    onClick={refreshIncidents}
                    disabled={loading}
                    className="rounded-lg bg-amber-400 px-3 py-2 text-sm font-bold text-white hover:bg-amber-500 disabled:opacity-60"
                    title="Refresh records"
                  >
                    ↻
                  </button>
                </div>
              </div>

              <input
                value={search}
                onChange={(event) => {
                  setSearch(event.target.value);
                  setPage(1);
                }}
                placeholder="Search incident name or location..."
                className="mt-4 w-full rounded-lg border border-blue-100 px-4 py-2.5 text-sm outline-none focus:border-blue-500"
              />

              {error && (
                <p
                  role="alert"
                  className="mt-3 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700"
                >
                  {error}
                </p>
              )}

              {loading ? (
                <div className="py-12 text-center text-sm text-slate-500">
                  Loading saved incidents...
                </div>
              ) : visibleIncidents.length === 0 ? (
                <div className="mt-4 rounded-xl border border-dashed border-blue-200 px-4 py-12 text-center">
                  <div className="text-4xl text-blue-300">▤</div>
                  <h3 className="mt-3 font-bold text-slate-600">
                    No Incidents Available
                  </h3>
                  <p className="mx-auto mt-2 max-w-md text-sm text-slate-400">
                    No incident records match your search. Create a new
                    incident above or clear the filters.
                  </p>
                </div>
              ) : (
                <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 2xl:grid-cols-3">
                  {visibleIncidents.map((incident) => (
                    <article
                      key={incident.id}
                      className="group relative flex min-h-[250px] flex-col overflow-hidden rounded-2xl border border-blue-100 bg-gradient-to-br from-white via-white to-blue-50/70 p-5 shadow-sm transition-all duration-300 ease-out hover:-translate-y-1.5 hover:border-blue-300 hover:shadow-xl hover:shadow-blue-900/10 active:scale-[0.985] motion-reduce:transform-none motion-reduce:transition-none"
                    >
                      <div className="absolute inset-x-0 top-0 h-1 origin-left scale-x-0 bg-gradient-to-r from-blue-500 to-sky-300 transition-transform duration-300 group-hover:scale-x-100" />
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex min-w-0 items-start gap-3">
                          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-blue-100 bg-blue-50 text-xl text-blue-700 transition-all duration-300 group-hover:rotate-[-4deg] group-hover:scale-110 group-hover:bg-blue-100 motion-reduce:transform-none">
                            {incident.incident_type === "Fire" ? "🔥" : incident.incident_type === "Medical" ? "✚" : incident.incident_type === "Rescue" ? "🛟" : incident.incident_type === "HAZMAT" ? "☣" : incident.incident_type === "Drill" ? "🎯" : "🚨"}
                          </div>
                          <div className="min-w-0">
                            <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-blue-500">{incident.incident_type || "Incident"}</p>
                            <h3 className="mt-1 break-words text-base font-extrabold leading-snug text-[#17365d]">{incident.incident_name}</h3>
                          </div>
                        </div>
                        <span className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-bold ${incident.status === "Closed" ? "bg-slate-100 text-slate-600" : incident.status === "Standby" ? "bg-blue-100 text-blue-700" : "bg-emerald-100 text-emerald-700"}`}>
                          {incident.status || "Active"}
                        </span>
                      </div>

                      <div className="mt-5 space-y-3 text-xs text-slate-600">
                        <div className="flex items-start gap-2.5">
                          <span className="mt-px text-sm text-blue-500">⌖</span>
                          <div className="min-w-0">
                            <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Location</p>
                            <p className="mt-0.5 break-words font-medium text-slate-700">{incident.location || "Not specified"}</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <span className="mt-px text-sm text-blue-500">◷</span>
                          <div>
                            <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Date / Time</p>
                            <p className="mt-0.5 font-medium text-slate-700">{incident.incident_date || "—"}{incident.incident_time ? ` · ${incident.incident_time.slice(0, 5)}` : ""}</p>
                          </div>
                        </div>
                      </div>

                      <div className="mt-auto grid grid-cols-[minmax(0,1fr)_auto_auto] gap-2 border-t border-blue-100/80 pt-4 mt-5">
                        <button
                          type="button"
                          onClick={() => router.push(`/incident?incidentId=${encodeURIComponent(incident.id)}`)}
                          className="rounded-lg bg-blue-600 px-3 py-2.5 text-xs font-bold text-white shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:bg-blue-700 hover:shadow-md active:scale-95 motion-reduce:transform-none"
                        >
                          View Incident
                        </button>
                        <button
                          type="button"
                          onClick={() => { setSelectedIncident(incident); setEditingIncident(true); }}
                          className="rounded-lg border border-blue-200 bg-blue-50 px-3 py-2.5 text-sm font-bold text-blue-700 transition-all duration-200 hover:-translate-y-0.5 hover:border-blue-300 hover:bg-blue-100 active:scale-95 motion-reduce:transform-none"
                          aria-label={`Edit ${incident.incident_name}`}
                          title="Edit incident"
                        >
                          ✎ <span className="text-xs">Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => void deleteIncident(incident)}
                          className="rounded-lg border border-red-100 bg-red-50 px-3 py-2.5 text-sm font-bold text-red-600 transition-all duration-200 hover:-translate-y-0.5 hover:border-red-200 hover:bg-red-100 active:scale-95 motion-reduce:transform-none"
                          aria-label={`Delete ${incident.incident_name}`}
                          title="Delete incident"
                        >
                          × <span className="text-xs">Delete</span>
                        </button>
                      </div>
                    </article>
                  ))}
                </div>
              )}

              {!loading && filteredIncidents.length > 0 && (
                <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-blue-50 pt-4">
                  <p className="text-xs text-slate-500">
                    Showing {(page - 1) * pageSize + 1}–
                    {Math.min(page * pageSize, filteredIncidents.length)} of{" "}
                    {filteredIncidents.length} records
                  </p>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      disabled={page <= 1}
                      onClick={() => setPage((current) => current - 1)}
                      className="rounded-lg border border-blue-100 px-3 py-2 text-sm disabled:opacity-40"
                    >
                      ‹
                    </button>

                    <span className="rounded-lg bg-blue-600 px-3 py-2 text-sm font-bold text-white">
                      {page}
                    </span>

                    <button
                      type="button"
                      disabled={page >= totalPages}
                      onClick={() => setPage((current) => current + 1)}
                      className="rounded-lg border border-blue-100 px-3 py-2 text-sm disabled:opacity-40"
                    >
                      ›
                    </button>
                  </div>
                </div>
              )}
            </section>
          </div>
        </section>
      </div>

      {selectedIncident && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm"
          onClick={(event) => {
            if (event.target === event.currentTarget) {
              setSelectedIncident(null);
              setEditingIncident(false);
              setEditNotice("");
            }
          }}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="incident-detail-title"
            className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white shadow-2xl"
          >
            <div className="flex items-start justify-between gap-4 border-b border-blue-100 bg-blue-50 px-6 py-5">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-blue-600">
                  {editingIncident ? "Edit Incident" : "Incident Details"}
                </p>
                <h2 id="incident-detail-title" className="mt-1 text-xl font-extrabold text-slate-900">
                  {selectedIncident.incident_name}
                </h2>
                <p className="mt-1 text-sm text-slate-500">Reference ID: {selectedIncident.id}</p>
              </div>
              <button
                type="button"
                aria-label="Close incident details"
                onClick={() => {
                  setSelectedIncident(null);
                  setEditingIncident(false);
                  setEditNotice("");
                }}
                className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-lg font-bold text-slate-500 hover:bg-slate-100"
              >
                ×
              </button>
            </div>

            <div className="grid grid-cols-1 gap-4 p-6 sm:grid-cols-2">
              <label className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs font-bold text-slate-500">
                Incident Name
                <input
                  disabled={!editingIncident}
                  value={selectedIncident.incident_name}
                  onChange={(e) => setSelectedIncident({ ...selectedIncident, incident_name: e.target.value })}
                  className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-800 disabled:bg-slate-100"
                />
              </label>
              <label className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs font-bold text-slate-500">
                Incident Type
                <select
                  disabled={!editingIncident}
                  value={selectedIncident.incident_type || ""}
                  onChange={(e) => setSelectedIncident({ ...selectedIncident, incident_type: e.target.value || null })}
                  className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-800 disabled:bg-slate-100"
                >
                  <option value="">Not specified</option>
                  <option value="Fire">Fire</option><option value="Medical">Medical</option>
                  <option value="Rescue">Rescue</option><option value="HAZMAT">HAZMAT</option>
                  <option value="Drill">Drill</option><option value="Other">Other</option>
                </select>
              </label>
              <label className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs font-bold text-slate-500">
                Location
                <input disabled={!editingIncident} value={selectedIncident.location || ""}
                  onChange={(e) => setSelectedIncident({ ...selectedIncident, location: e.target.value || null })}
                  className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-800 disabled:bg-slate-100" />
              </label>
              <label className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs font-bold text-slate-500">
                Incident Date
                <input type="date" disabled={!editingIncident} value={selectedIncident.incident_date || ""}
                  onChange={(e) => setSelectedIncident({ ...selectedIncident, incident_date: e.target.value || null })}
                  className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-800 disabled:bg-slate-100" />
              </label>
              <label className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs font-bold text-slate-500">
                Incident Time
                <input type="time" disabled={!editingIncident} value={selectedIncident.incident_time || ""}
                  onChange={(e) => setSelectedIncident({ ...selectedIncident, incident_time: e.target.value || null })}
                  className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-800 disabled:bg-slate-100" />
              </label>
              <label className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs font-bold text-slate-500">
                Fire Type
                <select disabled={!editingIncident} value={selectedIncident.fire_type || ""}
                  onChange={(e) => setSelectedIncident({ ...selectedIncident, fire_type: e.target.value || null })}
                  className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-800 disabled:bg-slate-100">
                  <option value="Real">Real</option><option value="Drill">Drill</option>
                </select>
              </label>
              <label className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs font-bold text-slate-500">
                Status
                <select disabled={!editingIncident} value={selectedIncident.status}
                  onChange={(e) => setSelectedIncident({ ...selectedIncident, status: e.target.value })}
                  className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-800 disabled:bg-slate-100">
                  <option value="Active">Active</option><option value="Monitoring">Monitoring</option>
                  <option value="Resolved">Resolved</option><option value="Closed">Closed</option>
                </select>
              </label>
              <label className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs font-bold text-slate-500 sm:col-span-2">
                Description
                <textarea rows={4} disabled={!editingIncident} value={selectedIncident.description || ""}
                  onChange={(e) => setSelectedIncident({ ...selectedIncident, description: e.target.value || null })}
                  className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-normal leading-6 text-slate-800 disabled:bg-slate-100" />
              </label>
              <div className="text-xs text-slate-400 sm:col-span-2">
                Created: {selectedIncident.created_at ? new Date(selectedIncident.created_at).toLocaleString() : "Not specified"}
              </div>
            </div>

            {editNotice && <p role="status" className="mx-6 mb-2 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700">{editNotice}</p>}

            <div className="flex flex-wrap justify-end gap-2 border-t border-slate-100 px-6 py-4">
              {editingIncident ? (
                <>
                  <button type="button" onClick={() => {
                    const original = incidents.find((item) => item.id === selectedIncident.id);
                    if (original) setSelectedIncident(original);
                    setEditingIncident(false);
                    setEditNotice("");
                  }} className="rounded-lg border border-slate-200 px-4 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-50">Cancel</button>
                  <button type="button" onClick={async () => {
                    if (!selectedIncident.incident_name.trim()) {
                      setEditNotice("Incident name cannot be empty.");
                      return;
                    }
                    setEditNotice("");
                    try {
                      await emtApi("PATCH", {
                        id: selectedIncident.id,
                        incident: {
                          incident_name: selectedIncident.incident_name,
                          incident_type: selectedIncident.incident_type,
                          location: selectedIncident.location,
                          incident_date: selectedIncident.incident_date,
                          incident_time: selectedIncident.incident_time,
                          fire_type: selectedIncident.fire_type,
                          description: selectedIncident.description,
                          status: selectedIncident.status,
                        },
                      });

                      setIncidents((current) => current.map((item) => item.id === selectedIncident.id ? selectedIncident : item));
                      setEditingIncident(false);
                      setEditNotice("Incident updated successfully.");
                    } catch (caught) {
                      setEditNotice(caught instanceof Error ? caught.message : "Unable to update incident.");
                    }
                  }} className="rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-blue-700">Save Changes</button>
                </>
              ) : (
                <>
                  <button type="button" onClick={() => { setEditingIncident(true); setEditNotice(""); }}
                    className="rounded-lg bg-amber-500 px-5 py-2.5 text-sm font-bold text-white hover:bg-amber-600">✎ Edit Incident</button>
                  <button type="button" onClick={() => setSelectedIncident(null)}
                    className="rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-blue-700">Close</button>
                </>
              )}
            </div>
          </section>
        </div>
      )}
    </main>
  );
}
