"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";

type Incident = {
  id: string;
  incident_name: string;
  incident_type?: string | null;
  location?: string | null;
  incident_date?: string | null;
  incident_time?: string | null;
  fire_type?: string | null;
  description?: string | null;
  status?: string | null;
  created_at?: string;
  [key: string]: unknown;
};

type RelatedRecord = {
  id?: string | number;
  incidentId?: string | number;
  incident_id?: string | number;
  incidentName?: string;
  incident_name?: string;
  date?: string;
  time?: string;
  datetime?: string;
  created_at?: string;
  information?: string;
  description?: string;
  details?: string;
  status?: string;
  categories?: string[];
  category?: string;
  pear_category?: string;
  [key: string]: unknown;
};

function readLocalArray<T>(key: string): T[] {
  try {
    const value = window.localStorage.getItem(key);
    if (!value) return [];
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? (parsed as T[]) : [];
  } catch {
    return [];
  }
}

function recordBelongsToIncident(record: RelatedRecord, incident: Incident) {
  const recordId = record.incidentId ?? record.incident_id;
  if (recordId !== undefined && recordId !== null) {
    return String(recordId) === String(incident.id);
  }

  const recordName = record.incidentName ?? record.incident_name;
  return Boolean(recordName && recordName === incident.incident_name);
}

function displayValue(value: unknown, fallback = "—") {
  if (value === null || value === undefined || value === "") return fallback;
  if (typeof value === "string" || typeof value === "number") return String(value);
  return JSON.stringify(value);
}

export default function PublicDashboardPage() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [chronology, setChronology] = useState<RelatedRecord[]>([]);
  const [ipStatuses, setIpStatuses] = useState<RelatedRecord[]>([]);
  const [pearRecords, setPearRecords] = useState<RelatedRecord[]>([]);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("newest");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  function loadAllRecords() {
    setError("");
    try {
      setIncidents(readLocalArray<Incident>("emt_incidents"));
      setChronology(readLocalArray<RelatedRecord>("emt_chronology"));
      setIpStatuses(readLocalArray<RelatedRecord>("emt_ip_status"));
      setPearRecords(readLocalArray<RelatedRecord>("emt_pear"));
    } catch {
      setError("Unable to read incident records from this browser.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAllRecords();

    // Refresh the public view when another tab in the same browser updates localStorage.
    function handleStorage(event: StorageEvent) {
      if (
        !event.key ||
        ["emt_incidents", "emt_chronology", "emt_ip_status", "emt_pear"].includes(event.key)
      ) {
        loadAllRecords();
      }
    }

    window.addEventListener("storage", handleStorage);
    return () => window.removeEventListener("storage", handleStorage);
  }, []);

  const filteredIncidents = useMemo(() => {
    const term = search.trim().toLowerCase();
    return incidents
      .filter((incident) => {
        const searchableText = [
          incident.incident_name,
          incident.incident_type ?? "",
          incident.location ?? "",
          incident.fire_type ?? "",
          incident.status ?? "",
        ]
          .join(" ")
          .toLowerCase();
        return searchableText.includes(term);
      })
      .sort((a, b) => {
        const dateA = a.incident_date ?? a.created_at ?? "";
        const dateB = b.incident_date ?? b.created_at ?? "";
        return sort === "newest"
          ? dateB.localeCompare(dateA)
          : dateA.localeCompare(dateB);
      });
  }, [incidents, search, sort]);

  const selectedChronology = selectedIncident
    ? chronology.filter((record) => recordBelongsToIncident(record, selectedIncident))
    : [];
  const selectedIpStatuses = selectedIncident
    ? ipStatuses.filter((record) => recordBelongsToIncident(record, selectedIncident))
    : [];
  const selectedPear = selectedIncident
    ? pearRecords.filter((record) => recordBelongsToIncident(record, selectedIncident))
    : [];

  function formatDate(value?: string | null) {
    if (!value) return "—";
    const date = new Date(`${value.slice(0, 10)}T00:00:00`);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  }

  function formatRecord(record: RelatedRecord, index: number) {
    return (
      <article
        key={String(record.id ?? `${index}-${record.datetime ?? record.date ?? ""}`)}
        className="rounded-xl border border-slate-200 bg-white p-4"
      >
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h4 className="text-sm font-bold text-[#17365d]">
            {displayValue(record.title ?? record.information ?? record.description ?? record.details, `Record ${index + 1}`)}
          </h4>
          <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-semibold text-slate-600">
            {displayValue(record.status, "Record")}
          </span>
        </div>
        <p className="mt-2 whitespace-pre-wrap text-xs leading-5 text-slate-600">
          {displayValue(record.information ?? record.description ?? record.details, "No additional information")}
        </p>
        <div className="mt-3 flex flex-wrap gap-2 text-[10px] text-slate-400">
          {(record.datetime || record.date) && (
            <span>{displayValue(record.datetime ?? record.date)}</span>
          )}
          {record.time && <span>{record.time}</span>}
          {(record.pear_category || record.category) && (
            <span>Category: {displayValue(record.pear_category ?? record.category)}</span>
          )}
          {Array.isArray(record.categories) && record.categories.length > 0 && (
            <span>Categories: {record.categories.join(", ")}</span>
          )}
        </div>
      </article>
    );
  }

  return (
    <div className="flex min-h-screen bg-[#eaf2ff] text-[#102653]">
      <aside className="hidden w-[230px] shrink-0 flex-col bg-[#08264b] text-white md:flex">
        <div className="border-b border-white/10 px-5 py-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-xl">🛡️</div>
            <div>
              <h1 className="text-lg font-extrabold tracking-wide">EMT SYSTEM</h1>
              <p className="text-[10px] text-blue-200">Emergency Management Team</p>
            </div>
          </div>
        </div>

        <nav className="space-y-2 p-3">
          <Link href="/public-dashboard" className="flex items-center gap-3 rounded-lg bg-blue-600 px-4 py-3 text-sm font-semibold text-white">
            <span className="text-lg">⌂</span> Public Dashboard
          </Link>
        </nav>

        <div className="mt-auto px-4 py-8 text-center">
          <p className="text-[9px] font-semibold tracking-widest text-blue-200">SAFE · PREPARE · RESPOND · RECOVER</p>
          <p className="mt-4 text-xs font-medium leading-relaxed">&quot;Better Prepared,<br />Safer Tomorrow&quot;</p>
        </div>
      </aside>

      <main className="min-w-0 flex-1">
        <header className="bg-gradient-to-r from-blue-200 via-blue-300 to-[#648dd0] px-5 py-7 sm:px-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="mb-2 text-xs font-bold uppercase tracking-[0.18em] text-blue-950/70">Emergency Management Team</p>
              <h2 className="text-2xl font-extrabold text-white sm:text-3xl">Public Dashboard</h2>
              <p className="mt-2 max-w-xl text-sm leading-6 text-white/90">
                View incident records and related chronology, IP Status and PEAR information.
              </p>
            </div>
            <span className="rounded-full border border-white/40 bg-emerald-400 px-4 py-2 text-xs font-bold text-white shadow-sm">PUBLIC ACCESS · READ ONLY</span>
          </div>
        </header>

        <div className="space-y-5 p-4 sm:p-7">
          <section className="overflow-hidden rounded-xl border border-blue-100 bg-white shadow-sm">
            <div className="flex flex-col justify-between gap-4 border-b border-blue-50 p-5 lg:flex-row lg:items-center">
              <div>
                <h3 className="font-bold text-[#17365d]"><span className="mr-2 text-blue-600">◷</span>Incident Records</h3>
                <p className="mt-1 text-xs text-slate-500">Read-only records from the Admin Dashboard in this browser.</p>
              </div>
              <div className="flex flex-col gap-2 sm:flex-row">
                <input
                  type="search"
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Search incidents..."
                  className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-blue-500 sm:w-64"
                />
                <select value={sort} onChange={(event) => setSort(event.target.value)} className="rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm" aria-label="Sort incidents">
                  <option value="newest">Latest First</option>
                  <option value="oldest">Oldest First</option>
                </select>
                <button type="button" onClick={loadAllRecords} className="rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-blue-700">Refresh</button>
              </div>
            </div>

            <div className="mx-5 mt-4 rounded-lg border border-blue-100 bg-blue-50/70 px-4 py-3 text-xs text-slate-600">
              {loading ? "Loading incident records..." : `${filteredIncidents.length} record(s) found`}
            </div>

            {error && <div className="m-5 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}

            {!loading && !error && filteredIncidents.length === 0 && (
              <div className="px-5 py-16 text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-blue-50 text-3xl text-blue-400">▤</div>
                <h3 className="mt-4 font-bold text-[#17365d]">No incident records available</h3>
                <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-500">
                  Create an incident in Admin Dashboard using this same browser, then refresh this page.
                </p>
              </div>
            )}

            {!loading && !error && filteredIncidents.length > 0 && (
              <div className="grid grid-cols-1 gap-4 p-5 lg:grid-cols-2 xl:grid-cols-3">
                {filteredIncidents.map((incident) => (
                  <article key={incident.id} className="flex flex-col rounded-xl border border-blue-100 bg-white p-5 transition hover:border-blue-300 hover:shadow-md">
                    <div className="flex items-start justify-between gap-3">
                      <h4 className="font-bold text-[#17365d]">{incident.incident_name}</h4>
                      <span className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-bold ${incident.status === "Closed" ? "bg-slate-100 text-slate-600" : "bg-emerald-100 text-emerald-700"}`}>
                        {incident.status || "Unspecified"}
                      </span>
                    </div>
                    <div className="mt-4 space-y-3 text-xs text-slate-600">
                      <p><span className="font-semibold text-slate-800">Type:</span> {incident.incident_type || "—"}</p>
                      <p><span className="font-semibold text-slate-800">Fire Type:</span> {incident.fire_type || "—"}</p>
                      <p><span className="font-semibold text-slate-800">Date:</span> {formatDate(incident.incident_date)}</p>
                      <p><span className="font-semibold text-slate-800">Time:</span> {incident.incident_time || "—"}</p>
                      <p><span className="font-semibold text-slate-800">Location:</span> {incident.location || "—"}</p>
                    </div>
                    {incident.description && <p className="mt-4 line-clamp-3 text-xs leading-5 text-slate-500">{incident.description}</p>}
                    <button type="button" onClick={() => setSelectedIncident(incident)} className="mt-5 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-blue-700">
                      View Incident Details
                    </button>
                  </article>
                ))}
              </div>
            )}
            <div className="border-t border-blue-50 px-5 py-4 text-xs text-slate-500">Public viewing · Read-only</div>
          </section>
        </div>
      </main>

      {selectedIncident && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-3 backdrop-blur-sm sm:p-6" onClick={(event) => { if (event.target === event.currentTarget) setSelectedIncident(null); }}>
          <section role="dialog" aria-modal="true" aria-labelledby="public-incident-title" className="max-h-[92vh] w-full max-w-5xl overflow-y-auto rounded-2xl bg-[#f8fbff] shadow-2xl">
            <header className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-blue-100 bg-white px-5 py-4 sm:px-7">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-blue-600">Public Incident Details · Read Only</p>
                <h2 id="public-incident-title" className="mt-1 text-xl font-extrabold text-[#17365d] sm:text-2xl">{selectedIncident.incident_name}</h2>
                <p className="mt-1 text-xs text-slate-500">Reference ID: {selectedIncident.id}</p>
              </div>
              <button type="button" onClick={() => setSelectedIncident(null)} aria-label="Close details" className="rounded-lg border border-slate-200 px-3 py-1 text-2xl text-slate-500 hover:bg-slate-100">×</button>
            </header>

            <div className="space-y-5 p-5 sm:p-7">
              <section className="rounded-xl border border-blue-100 bg-white p-5">
                <h3 className="mb-4 font-bold text-[#17365d]">Incident Information</h3>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {[
                    ["Incident Name", selectedIncident.incident_name],
                    ["Incident Type", selectedIncident.incident_type],
                    ["Date", formatDate(selectedIncident.incident_date)],
                    ["Time", selectedIncident.incident_time],
                    ["Location", selectedIncident.location],
                    ["Fire Type", selectedIncident.fire_type],
                    ["Status", selectedIncident.status],
                  ].map(([label, value]) => (
                    <div key={label} className="rounded-lg bg-slate-50 p-3">
                      <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400">{label}</p>
                      <p className="mt-1 whitespace-pre-wrap text-sm font-semibold text-slate-700">{displayValue(value)}</p>
                    </div>
                  ))}
                  <div className="rounded-lg bg-slate-50 p-3 sm:col-span-2 lg:col-span-3">
                    <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Description</p>
                    <p className="mt-1 whitespace-pre-wrap text-sm leading-6 text-slate-700">{displayValue(selectedIncident.description)}</p>
                  </div>
                </div>
              </section>

              {[
                { title: "Chronology", records: selectedChronology },
                { title: "IP Status", records: selectedIpStatuses },
                { title: "PEAR", records: selectedPear },
              ].map((section) => (
                <section key={section.title} className="rounded-xl border border-blue-100 bg-white p-5">
                  <div className="mb-4 flex items-center justify-between gap-3">
                    <h3 className="font-bold text-[#17365d]">{section.title}</h3>
                    <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700">{section.records.length} record(s)</span>
                  </div>
                  {section.records.length === 0 ? (
                    <p className="rounded-lg border border-dashed border-slate-200 p-5 text-center text-sm text-slate-400">No {section.title} records linked to this incident.</p>
                  ) : (
                    <div className="grid gap-3 md:grid-cols-2">
                      {section.records.map((record, index) => formatRecord(record, index))}
                    </div>
                  )}
                </section>
              ))}
            </div>

            <footer className="flex justify-end border-t border-blue-100 bg-white px-5 py-4 sm:px-7">
              <button type="button" onClick={() => setSelectedIncident(null)} className="rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-blue-700">Close</button>
            </footer>
          </section>
        </div>
      )}
    </div>
  );
}
