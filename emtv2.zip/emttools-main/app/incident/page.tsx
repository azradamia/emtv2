"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

type Incident = {
  id: string;
  name?: string;
  type?: string | null;
  date?: string | null;
  time?: string | null;
  fireType?: string | null;
  incident_name?: string;
  incident_type?: string | null;
  incident_date?: string | null;
  incident_time?: string | null;
  fire_type?: string | null;
  location?: string | null;
  description?: string | null;
  status?: string;
};
type Chronology = { id: number | string; incidentId: string; incidentName?: string; information?: string; categories?: string[]; date?: string; time?: string; reportedBy?: string; location?: string };
type IPRecord = { id: number | string; incidentId: string; reportedBy?: string; ipId?: string; status?: string; location?: string; information?: string; updatedAt?: string };
type PearRecord = { id: number | string; incidentId: string; category?: string; description?: string; status?: string; updatedAt?: string };

const menu = [
  { label: "Dashboard", href: "/dashboard", icon: "⌂" },
  { label: "Incidents", href: "/incident", icon: "▤" },
  { label: "Chronology", href: "/chronology", icon: "◷" },
  { label: "IP Status", href: "/ipstatus", icon: "▣" },
  { label: "PEAR", href: "/pear", icon: "♧" },
];

export default function IncidentPage() {
  const [incident, setIncident] = useState<Incident | null>(null);
  const [chronology, setChronology] = useState<Chronology[]>([]);
  const [ipRecords, setIpRecords] = useState<IPRecord[]>([]);
  const [pearRecords, setPearRecords] = useState<PearRecord[]>([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function loadIncident() {
      try {
        const params = new URLSearchParams(window.location.search);
        const incidentId = params.get("incidentId");

        // Load the shared incident record from the Supabase-backed API.
        const response = await fetch("/api/incidents", { cache: "no-store" });
        const result = await response.json();

        if (!response.ok) {
          throw new Error(result?.error || "Unable to load incidents from database.");
        }

        const rows = (Array.isArray(result) ? result : result.incidents ?? []) as Incident[];
        const normalized = rows.map((raw) => ({
          ...raw,
          id: String(raw.id),
          name: raw.name ?? raw.incident_name ?? "",
          type: raw.type ?? raw.incident_type ?? "",
          date: raw.date ?? raw.incident_date ?? "",
          time: raw.time ?? raw.incident_time ?? "",
          fireType: raw.fireType ?? raw.fire_type ?? "",
          location: raw.location ?? "",
          description: raw.description ?? "",
          status: raw.status ?? "Active",
        }));

        // If an ID was requested, show that exact incident; don't silently fall back
        // to the first record, because that can look like the wrong incident.
        const chosen = incidentId
          ? normalized.find((item) => String(item.id) === incidentId) ?? null
          : normalized[0] ?? null;

        if (!cancelled) {
          setIncident(chosen);
          // Load shared related records from the Supabase-backed APIs.
          // Keep PEAR local until its API route is implemented.
          const [chronologyResponse, ipResponse] = await Promise.all([
            fetch("/api/chronology", { cache: "no-store" }),
            fetch("/api/ip-status", { cache: "no-store" }),
          ]);

          const [chronologyResult, ipResult] = await Promise.all([
            chronologyResponse.json(),
            ipResponse.json(),
          ]);

          if (!chronologyResponse.ok) {
            throw new Error(
              chronologyResult?.error ||
                `Unable to load chronology (HTTP ${chronologyResponse.status}).`
            );
          }

          if (!ipResponse.ok) {
            throw new Error(
              ipResult?.error ||
                `Unable to load IP Status (HTTP ${ipResponse.status}).`
            );
          }

          const chronologyRows = Array.isArray(chronologyResult)
            ? chronologyResult
            : chronologyResult?.records ?? [];
          const ipRows = Array.isArray(ipResult)
            ? ipResult
            : ipResult?.records ?? [];

          setChronology(
            chronologyRows.map((row: any) => ({
              ...row,
              id: String(row.id),
              incidentId: String(row.incidentId ?? row.incident_id ?? ""),
              incidentName: row.incidentName ?? row.incident_name ?? "",
              information: row.information ?? "",
              categories: Array.isArray(row.categories) ? row.categories : [],
              date: row.date ?? "",
              time: row.time ?? "",
            }))
          );

          setIpRecords(
            ipRows.map((row: any) => ({
              ...row,
              id: String(row.id),
              incidentId: String(row.incidentId ?? row.incident_id ?? ""),
              reportedBy: row.reportedBy ?? row.reported_by ?? "",
              ipId: row.ipId ?? row.ip_id ?? "",
              status: row.status ?? "",
              location: row.location ?? "",
              information: row.information ?? "",
              updatedAt: row.updatedAt ?? row.updated_at ?? "",
            }))
          );

          setPearRecords(JSON.parse(localStorage.getItem("emt_pear") || "[]"));
        }
      } catch (error) {
        console.error("Unable to load incident details", error);
        // Keep the incident page visible even if a related module API fails.
        // The console records which related API needs attention.
        if (!cancelled) {
          const params = new URLSearchParams(window.location.search);
          const incidentId = params.get("incidentId");
          if (!incidentId) setIncident(null);
        }
      } finally {
        if (!cancelled) setLoaded(true);
      }
    }

    void loadIncident();
    return () => { cancelled = true; };
  }, []);

  const relatedChronology = chronology.filter((r) => String(r.incidentId) === String(incident?.id));
  const relatedIP = ipRecords.filter((r) => String(r.incidentId) === String(incident?.id));
  const relatedPear = pearRecords.filter((r) => String(r.incidentId) === String(incident?.id));

  return (
    <div className="flex min-h-screen bg-[#edf4fc] text-slate-800">
      <style jsx global>{`
        @keyframes emtFadeInUp {
          from { opacity: 0; transform: translateY(12px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .emt-fade-in-up { animation: emtFadeInUp 420ms ease-out both; }
        .emt-hover-card { transition: transform 220ms ease, box-shadow 220ms ease, border-color 220ms ease; }
        .emt-hover-card:hover { transform: translateY(-3px); box-shadow: 0 12px 26px rgba(30, 64, 175, 0.10); border-color: #bfdbfe; }
        .emt-action-button { transition: transform 160ms ease, background-color 180ms ease, box-shadow 180ms ease; }
        .emt-action-button:hover { transform: translateY(-1px); box-shadow: 0 5px 12px rgba(37, 99, 235, 0.16); }
        .emt-action-button:active { transform: scale(0.97); }
        @media (prefers-reduced-motion: reduce) {
          .emt-fade-in-up, .emt-hover-card, .emt-action-button { animation: none !important; transition: none !important; }
          .emt-hover-card:hover, .emt-action-button:hover, .emt-action-button:active { transform: none; }
        }
      `}</style>
      <aside className="hidden w-[220px] shrink-0 flex-col bg-[#102f50] text-white md:flex">
        <div className="border-b border-white/10 px-4 py-5"><h1 className="text-lg font-extrabold tracking-wide">🚒 EMT SYSTEM</h1><p className="mt-1 text-[10px] text-blue-200">Emergency Management Team</p></div>
        <nav className="space-y-1 p-3 text-sm">{menu.map((item) => <Link key={item.label} href={item.href} className={`flex items-center gap-3 rounded-lg px-3 py-3 ${item.label === "Incidents" ? "bg-blue-500 font-semibold text-white" : "text-blue-100 hover:bg-white/10"}`}><span className="text-lg">{item.icon}</span>{item.label}</Link>)}</nav>
        <div className="mt-auto px-4 py-8 text-center text-[10px] text-blue-200">SAFE · PREPARE · RESPOND · RECOVER<p className="mt-4 text-sm font-bold text-white">Better Prepared,<br />Safer Tomorrow</p></div>
      </aside>
      {mobileMenuOpen && <div className="fixed inset-0 z-50 md:hidden"><button aria-label="Close navigation" className="absolute inset-0 bg-slate-950/60" onClick={() => setMobileMenuOpen(false)} /><aside className="relative z-10 flex h-full w-[min(82vw,300px)] flex-col bg-[#102f50] text-white"><div className="flex items-center justify-between border-b border-white/10 px-4 py-5"><h1 className="font-extrabold">🚒 EMT SYSTEM</h1><button onClick={() => setMobileMenuOpen(false)} className="px-2 text-2xl">×</button></div><nav className="space-y-1 p-3 text-sm">{menu.map((item) => <Link key={item.label} href={item.href} onClick={() => setMobileMenuOpen(false)} className={`flex items-center gap-3 rounded-lg px-3 py-3 ${item.label === "Incidents" ? "bg-blue-500 font-semibold" : "text-blue-100 hover:bg-white/10"}`}>{item.icon} {item.label}</Link>)}</nav></aside></div>}

      <main className="min-w-0 flex-1">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-blue-100 bg-gradient-to-r from-blue-50 via-sky-100 to-white px-4 py-4 sm:px-8 sm:py-5">
          <div className="flex items-center gap-3"><button type="button" aria-label="Open navigation menu" onClick={() => setMobileMenuOpen(true)} className="flex h-10 w-10 items-center justify-center rounded-lg border border-blue-200 bg-white text-xl text-[#17365d] md:hidden">☰</button><div><h2 className="text-xl font-bold text-[#15365f] sm:text-2xl">Incident Information</h2><p className="mt-1 text-xs text-slate-500">Incident overview and related operational records</p></div></div>
          <Link href="/dashboard" className="rounded-lg bg-emerald-500 px-4 py-2.5 text-sm font-bold text-white shadow-sm hover:bg-emerald-600">＋ Create New</Link>
        </header>

        <div className="p-4 sm:p-7">
          {!loaded ? <div className="rounded-xl bg-white p-8 text-center text-slate-500">Loading incident information…</div> : !incident ? <section className="rounded-xl border border-blue-100 bg-white p-8 text-center shadow-sm"><h3 className="text-lg font-bold text-[#17365d]">No incident selected</h3><p className="mt-2 text-sm text-slate-500">Create an incident or select View from All Incidents on the Dashboard.</p><Link href="/dashboard" className="mt-5 inline-flex rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white">Go to Dashboard</Link></section> : <>
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div><p className="text-xs font-semibold uppercase tracking-wider text-blue-600">Selected Incident</p><h3 className="mt-1 text-lg font-bold text-[#17365d]">{incident.name || incident.incident_name}</h3></div><span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">{incident.status || "Active"}</span></div>
            <div className="grid grid-cols-1 items-start gap-5 xl:grid-cols-2">
              <section className="emt-fade-in-up emt-hover-card rounded-xl border border-slate-100 bg-white p-5 shadow-sm"><div className="mb-4 border-b border-slate-100 pb-3"><h3 className="font-bold text-[#17365d]">🔥 INCIDENT</h3></div><div className="space-y-2.5">{[["Incident Name", incident.name || incident.incident_name || "—"],["Date", incident.date || incident.incident_date || "—"],["Type of Incident", incident.type || incident.incident_type || "—"],["Location", incident.location || "—"],["Fire Type", incident.fireType || incident.fire_type || "—"],["Description", incident.description || "No description provided"]].map(([label,value])=><div key={label} className="flex flex-col gap-1 rounded-lg border border-slate-100 bg-slate-50 px-3 py-2.5 sm:flex-row sm:items-start sm:justify-between"><span className="text-xs text-blue-700">{label}:</span><span className="break-words text-sm font-medium sm:max-w-[70%] sm:text-right">{value}</span></div>)}</div></section>

              <section className="emt-fade-in-up emt-hover-card rounded-xl border border-slate-100 bg-white p-5 shadow-sm" style={{ animationDelay: "80ms" }}><div className="mb-4 flex items-center justify-between border-b border-slate-100 pb-3"><h3 className="font-bold text-[#17365d]">◷ CHRONOLOGY <span className="text-xs font-normal text-slate-400">({relatedChronology.length})</span></h3><Link href={`/chronology?incidentId=${encodeURIComponent(incident.id)}`} className="emt-action-button rounded-lg bg-blue-600 px-3 py-2 text-xs font-bold text-white">⚙ Manage</Link></div><div className="max-h-[350px] space-y-3 overflow-y-auto">{relatedChronology.length ? relatedChronology.map((r,i)=><article key={r.id} className="rounded-lg border border-slate-200 p-3"><div className="mb-2 flex items-center justify-between gap-2 border-b border-slate-100 pb-2 text-xs text-blue-700"><span>⚑ Chronology #{i+1}</span><span className="text-slate-500">◷ {r.date || "—"} {r.time || ""}</span></div><p className="whitespace-pre-wrap text-sm">{r.information || "No information"}</p>{r.categories?.length ? <p className="mt-2 text-xs text-slate-500">{r.categories.join(", ")}</p> : null}</article>) : <p className="rounded-lg border border-slate-100 p-4 text-sm text-slate-500">No chronology data available for this incident.</p>}</div><Link href={`/chronology?incidentId=${encodeURIComponent(incident.id)}`} className="emt-action-button mt-3 inline-flex rounded-md px-1 py-1 text-xs font-semibold text-blue-700 hover:underline">＋ Add Chronology</Link></section>

              <section className="emt-fade-in-up emt-hover-card rounded-xl border border-slate-100 bg-white p-5 shadow-sm" style={{ animationDelay: "140ms" }}><div className="mb-4 flex items-center justify-between border-b border-slate-100 pb-3"><h3 className="font-bold text-[#17365d]">⬟ IP STATUS <span className="text-xs font-normal text-slate-400">({relatedIP.length})</span></h3><Link href={`/ipstatus?incidentId=${encodeURIComponent(incident.id)}`} className="emt-action-button rounded-lg bg-blue-600 px-3 py-2 text-xs font-bold text-white">⚙ Manage</Link></div><div className="max-h-[350px] space-y-3 overflow-y-auto">{relatedIP.length ? relatedIP.map((r,i)=><article key={r.id} className="rounded-lg border border-slate-200 p-3"><div className="mb-2 flex items-center justify-between gap-2 border-b border-slate-100 pb-2 text-xs text-blue-700"><span>⬟ IP Status #{i+1}</span><span className="text-slate-500">{r.updatedAt || ""}</span></div><div className="grid grid-cols-1 gap-1 text-sm sm:grid-cols-2"><p><span className="text-slate-500">Reported By:</span> {r.reportedBy || "—"}</p><p><span className="text-slate-500">IP ID:</span> {r.ipId || "—"}</p><p><span className="text-slate-500">IP Status:</span> {r.status || "—"}</p><p><span className="text-slate-500">Location:</span> {r.location || "—"}</p></div>{r.information && <p className="mt-2 text-sm">Info Incident: {r.information}</p>}</article>) : <p className="rounded-lg border border-slate-100 p-4 text-sm text-slate-500">No IP Status data available for this incident.</p>}</div><Link href={`/ipstatus?incidentId=${encodeURIComponent(incident.id)}`} className="emt-action-button mt-3 inline-flex rounded-md px-1 py-1 text-xs font-semibold text-blue-700 hover:underline">＋ Add IP Status</Link></section>

              <section className="emt-fade-in-up emt-hover-card rounded-xl border border-slate-100 bg-white p-5 shadow-sm" style={{ animationDelay: "200ms" }}><div className="mb-4 flex items-center justify-between border-b border-slate-100 pb-3"><h3 className="font-bold text-[#17365d]">▤ PEAR <span className="text-xs font-normal text-slate-400">({relatedPear.length})</span></h3><Link href={`/pear?incidentId=${encodeURIComponent(incident.id)}`} className="emt-action-button rounded-lg bg-blue-600 px-3 py-2 text-xs font-bold text-white">⚙ Manage</Link></div><div className="max-h-[350px] space-y-3 overflow-y-auto">{relatedPear.length ? relatedPear.map((r)=><article key={r.id} className="rounded-lg border border-slate-200 p-3"><p className="text-sm font-semibold text-blue-700">{r.category || "PEAR entry"}</p><p className="mt-1 whitespace-pre-wrap text-sm">{r.description || "—"}</p><p className="mt-2 text-xs text-slate-500">Status: {r.status || "—"}</p></article>) : <p className="rounded-lg border border-slate-100 p-4 text-sm text-slate-500">No PEAR data available for this incident.</p>}</div><Link href={`/pear?incidentId=${encodeURIComponent(incident.id)}`} className="emt-action-button mt-3 inline-flex rounded-md px-1 py-1 text-xs font-semibold text-blue-700 hover:underline">＋ Add PEAR</Link></section>
            </div>
          </>}
        </div>
      </main>
    </div>
  );
}
