
"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

type PearCategory = "People" | "Environment" | "Asset" | "Reputation";

type PearRecord = {
  id: number;
  incidentId: string;
  incidentName: string;
  category: PearCategory;
  description: string;
  status: string;
  updatedAt: string;
};

const categories: PearCategory[] = [
  "People",
  "Environment",
  "Asset",
  "Reputation",
];

type IncidentOption = { id: string | number; name?: string; incident_name?: string; type?: string; incident_type?: string; location?: string; date?: string; incident_date?: string };

export default function PearPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [records, setRecords] = useState<PearRecord[]>([]);
  const [incidents, setIncidents] = useState<IncidentOption[]>([]);
  const [incidentId, setIncidentId] = useState(""); 
  const [storageReady, setStorageReady] = useState(false);

  useEffect(() => {
    try {
      const savedIncidents = localStorage.getItem("emt_incidents");
      const parsedIncidents = savedIncidents ? JSON.parse(savedIncidents) : [];
      setIncidents(Array.isArray(parsedIncidents) ? parsedIncidents : []);
      const params = new URLSearchParams(window.location.search);
      setIncidentId(params.get("incidentId") || "");
      const savedPear = localStorage.getItem("emt_pear");
      const parsedPear = savedPear ? JSON.parse(savedPear) : [];
      setRecords(Array.isArray(parsedPear) ? parsedPear : []);
    } catch (error) {
      console.error("Unable to load PEAR records", error);
    } finally {
      setStorageReady(true);
    }
  }, []);

  useEffect(() => {
    if (storageReady) localStorage.setItem("emt_pear", JSON.stringify(records));
  }, [records, storageReady]);
  const [category, setCategory] = useState<PearCategory | "">("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("");
  const [searches, setSearches] = useState<Record<string, string>>({});
  const [sort, setSort] = useState("newest");
  const [editingId, setEditingId] = useState<number | null>(null);

  const inputClass =
    "w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100";

  const labelClass =
    "mb-1.5 block text-xs font-semibold text-slate-700";

  function resetForm() {
    // Keep the incident selected by the Incident Information page.
    setCategory("");
    setDescription("");
    setStatus("");
    setEditingId(null);
  }

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    if (!incidentId) {
      alert("Open PEAR from the selected incident's Incident Information page first.");
      return;
    }

    if (!category || !description.trim() || !status) {
      alert("Please complete all required fields.");
      return;
    }

    const chosenIncident = incidents.find((item) => String(item.id) === incidentId);
    if (!chosenIncident) {
      alert("Please select a valid incident.");
      return;
    }
    const record: PearRecord = {
      id: editingId ?? Date.now(),
      incidentId: String(chosenIncident.id),
      incidentName: String(chosenIncident.name ?? chosenIncident.incident_name ?? "Unnamed incident"),
      category,
      description: description.trim(),
      status,
      updatedAt: new Date().toLocaleString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }),
    };

    if (editingId !== null) {
      setRecords((old) =>
        old.map((item) => item.id === editingId ? record : item)
      );
    } else {
      setRecords((old) => [record, ...old]);
    }

    resetForm();
  }

  function handleEdit(record: PearRecord) {
    setEditingId(record.id);
    setIncidentId(record.incidentId || "");
    setCategory(record.category);
    setDescription(record.description);
    setStatus(record.status);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleDelete(id: number) {
    if (confirm("Are you sure you want to delete this PEAR entry?")) {
      setRecords((old) => old.filter((item) => item.id !== id));
    }
  }

  const categoryInfo: Record<
    PearCategory,
    { icon: string; description: string }
  > = {
    People: {
      icon: "♟",
      description: "People impact and personnel safety",
    },
    Environment: {
      icon: "◈",
      description: "Environmental impact and contamination",
    },
    Asset: {
      icon: "⚙",
      description: "Asset damage and operational impact",
    },
    Reputation: {
      icon: "★",
      description: "Reputation and stakeholder impact",
    },
  };

  function renderCategorySection(item: PearCategory) {
    const categoryRecords = records
      .filter((record) => record.category === item)
      .filter((record) => Boolean(incidentId) && String(record.incidentId) === String(incidentId))
      .filter((record) =>
        [record.description, record.status].some((value) =>
          value.toLowerCase().includes((searches[item] ?? "").toLowerCase())
        )
      )
      .sort((a, b) =>
        sort === "newest" ? b.id - a.id : a.id - b.id
      );

    return (
      <section
        key={item}
        className="overflow-hidden rounded-xl border border-blue-100 bg-white p-4 shadow-sm"
      >
        <div className="mb-3 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-100 text-lg text-blue-700">
              {categoryInfo[item].icon}
            </span>
            <div>
              <h3 className="font-bold text-[#17365d]">{item}</h3>
              <p className="text-xs text-slate-500">
                {categoryInfo[item].description}
              </p>
            </div>
          </div>

          <div className="flex gap-2">
            <input
              className={`${inputClass} sm:w-52`}
              value={searches[item] ?? ""}
              onChange={(e) =>
                setSearches((old) => ({
                  ...old,
                  [item]: e.target.value,
                }))
              }
              placeholder={`Search ${item.toLowerCase()} entries...`}
            />
            <select
              className={`${inputClass} sm:w-36`}
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              aria-label={`Sort ${item} entries`}
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[600px] border-collapse text-left text-xs">
            <thead>
              <tr className="bg-[#eaf3ff] text-[#25466f]">
                <th className="px-3 py-3 font-semibold">Incident</th>
                <th className="px-3 py-3 font-semibold">Last Updated</th>
                <th className="px-3 py-3 font-semibold">Description</th>
                <th className="px-3 py-3 font-semibold">Status</th>
                <th className="px-3 py-3 font-semibold">Actions</th>
              </tr>
            </thead>

            <tbody>
              {categoryRecords.map((record) => (
                <tr
                  key={record.id}
                  className="border-b border-slate-100 hover:bg-blue-50/50"
                >
                  <td className="whitespace-nowrap px-3 py-3 text-slate-500">
                    {record.updatedAt}
                  </td>
                  <td className="max-w-lg px-3 py-3">
                    {record.description}
                  </td>
                  <td className="px-3 py-3">
                    <span
                      className={`rounded-full px-3 py-1 font-semibold ${
                        record.status === "ONGOING"
                          ? "bg-amber-100 text-amber-700"
                          : record.status === "RESOLVED"
                            ? "bg-emerald-100 text-emerald-700"
                            : "bg-blue-100 text-blue-700"
                      }`}
                    >
                      {record.status}
                    </span>
                  </td>
                  <td className="px-3 py-3">
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => handleEdit(record)}
                        className="rounded-md bg-blue-100 px-2.5 py-1.5 text-blue-700 hover:bg-blue-200"
                        aria-label="Edit PEAR entry"
                      >
                        ✎
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(record.id)}
                        className="rounded-md bg-red-100 px-2.5 py-1.5 text-red-700 hover:bg-red-200"
                        aria-label="Delete PEAR entry"
                      >
                        🗑
                      </button>
                    </div>
                  </td>
                </tr>
              ))}

              {categoryRecords.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-3 py-7 text-center">
                    <p className="text-slate-400">
                      No entries found for this category.
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="mt-3 text-xs text-slate-500">
          Showing {categoryRecords.length} {item.toLowerCase()} entries
        </div>
      </section>
    );
  }

  return (
    <div className="flex min-h-screen bg-[#edf4fc] text-slate-800">
      {/* SIDEBAR */}
      <aside className="hidden w-[220px] shrink-0 flex-col bg-[#102f50] text-white md:flex">
        <div className="flex items-center gap-3 border-b border-white/10 px-4 py-5">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white text-xl">
            🚒
          </div>
          <div>
            <h1 className="text-lg font-extrabold tracking-wide">EMT SYSTEM</h1>
            <p className="text-[10px] text-blue-200">
              Emergency Management Team
            </p>
          </div>
        </div>

        <nav className="space-y-1 p-3 text-sm">
          {[
            { label: "Dashboard", href: "/dashboard", icon: "⌂" },
            { label: "Incidents", href: "/incident", icon: "▤" },
            { label: "Chronology", href: "/chronology", icon: "◷" },
            { label: "IP Status", href: "/ipstatus", icon: "▣" },
            { label: "PEAR", href: "/pear", icon: "♟" },
          ].map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className={`flex items-center gap-3 rounded-lg px-3 py-3 transition ${
                item.label === "PEAR"
                  ? "bg-blue-500 font-semibold text-white"
                  : "text-blue-100 hover:bg-white/10"
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="mt-auto bg-gradient-to-t from-orange-950/60 to-transparent px-4 py-8 text-center">
          <p className="text-[9px] font-semibold tracking-widest text-blue-200">
            SAFE · PREPARE · RESPOND · RECOVER
          </p>
          <p className="mt-4 text-xs leading-relaxed">
            &quot;Better Prepared,
            <br />
            Safer Tomorrow&quot;
          </p>
        </div>
      </aside>

      {/* MOBILE NAVIGATION */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <button
            type="button"
            aria-label="Close navigation"
            className="absolute inset-0 bg-black/50"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 flex h-full w-[280px] max-w-[85vw] flex-col bg-[#102f50] text-white shadow-2xl">
            <div className="flex items-center justify-between gap-3 border-b border-white/10 px-4 py-5">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white text-xl">🚒</div>
                <div>
                  <h1 className="text-lg font-extrabold tracking-wide">EMT SYSTEM</h1>
                  <p className="text-[10px] text-blue-200">Emergency Management Team</p>
                </div>
              </div>
              <button
                type="button"
                className="rounded-md px-2 py-1 text-2xl text-white hover:bg-white/10"
                aria-label="Close navigation"
                onClick={() => setMobileMenuOpen(false)}
              >
                ×
              </button>
            </div>
            <nav className="space-y-1 p-3 text-sm">
              {[
                { label: "Dashboard", href: "/dashboard", icon: "⌂" },
                { label: "Incidents", href: "/incident", icon: "▤" },
                { label: "Chronology", href: "/chronology", icon: "◷" },
                { label: "IP Status", href: "/ipstatus", icon: "▣" },
                { label: "PEAR", href: "/pear", icon: "♟" },
              ].map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-3 rounded-lg px-3 py-3 transition ${
                    item.label === "PEAR"
                      ? "bg-blue-500 font-semibold text-white"
                      : "text-blue-100 hover:bg-white/10"
                  }`}
                >
                  <span className="text-lg">{item.icon}</span>
                  {item.label}
                </Link>
              ))}
            </nav>
            <div className="mt-auto bg-gradient-to-t from-orange-950/60 to-transparent px-4 py-8 text-center">
              <p className="text-[9px] font-semibold tracking-widest text-blue-200">
                SAFE · PREPARE · RESPOND · RECOVER
              </p>
              <p className="mt-4 text-xs leading-relaxed">&quot;Better Prepared,<br />Safer Tomorrow&quot;</p>
            </div>
          </aside>
        </div>
      )}

      {/* MAIN CONTENT */}
      <main className="min-w-0 flex-1">
        <header className="flex min-h-[76px] items-center justify-between gap-3 border-b border-blue-100 bg-gradient-to-r from-blue-50 via-sky-100 to-white px-4 py-4 sm:px-7">
          <div className="flex items-center gap-3">
            <button
              type="button"
              className="rounded-md px-2 py-1 text-xl hover:bg-blue-100 md:hidden"
              aria-label="Open navigation"
              aria-expanded={mobileMenuOpen}
              onClick={() => setMobileMenuOpen(true)}
            >
              ☰
            </button>
            <div>
              <h2 className="text-xl font-bold text-[#15365f]">
                PEAR Management
              </h2>
              <p className="text-xs text-slate-500">
                Manage incident PEAR entries (People, Environment, Asset, Reputation)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden text-right sm:block">
              <p className="text-xs font-bold text-[#17365d]">EMT User</p>
              <p className="text-[10px] text-slate-500">Incident Commander</p>
            </div>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-100 font-bold text-blue-800">
              U
            </div>
          </div>
        </header>

        <div className="mx-auto max-w-[1500px] space-y-4 p-4 sm:p-6">
          {/* ADD PEAR ENTRY */}
          <section className="rounded-xl border border-blue-100 bg-white p-5 shadow-sm">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-bold text-[#17365d]">Selected Incident</h3>
                <p className="mt-1 text-xs text-slate-500">
                  {incidents.find((item) => String(item.id) === String(incidentId))
                    ? String(incidents.find((item) => String(item.id) === String(incidentId))?.name ?? incidents.find((item) => String(item.id) === String(incidentId))?.incident_name ?? "Unnamed incident")
                    : "No incident selected — open PEAR from Incident Information."}
                </p>
              </div>
              <Link href={incidentId ? `/incident?incidentId=${encodeURIComponent(incidentId)}` : "/dashboard"}
                className="rounded-lg border border-blue-200 px-3 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-50">
                ← Back to Incident Information
              </Link>
            </div>
            <div className="mb-4 flex items-center gap-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-500 text-xl text-white">
                {editingId !== null ? "✎" : "+"}
              </span>
              <div>
                <h3 className="font-bold text-[#17365d]">
                  {editingId !== null ? "Edit PEAR Entry" : "Add New PEAR Entry"}
                </h3>
                <p className="text-xs text-slate-500">
                  Record and classify the impact of the incident
                </p>
              </div>
            </div>

            <form
              onSubmit={handleSubmit}
              className="grid grid-cols-1 items-end gap-4 lg:grid-cols-[1fr_1.6fr_0.8fr_auto]"
            >
              <div>
                <label className={labelClass}>
                  Category <span className="text-red-500">*</span>
                </label>
                <select
                  className={inputClass}
                  value={category}
                  onChange={(e) => setCategory(e.target.value as PearCategory | "")}
                  required
                >
                  <option value="">Select a category</option>
                  {categories.map((item) => (
                    <option key={item} value={item}>{item}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelClass}>
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  className={inputClass}
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide detailed description..."
                  required
                />
              </div>

              <div>
                <label className={labelClass}>
                  Status <span className="text-red-500">*</span>
                </label>
                <select
                  className={inputClass}
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  required
                >
                  <option value="">Select status</option>
                  <option value="ONGOING">ONGOING</option>
                  <option value="MONITORING">MONITORING</option>
                  <option value="RESOLVED">RESOLVED</option>
                </select>
              </div>

              <div className="flex flex-wrap gap-2 lg:pb-0.5">
                <button
                  type="submit"
                  className="rounded-lg bg-blue-500 px-4 py-2.5 text-xs font-semibold text-white transition hover:bg-blue-600"
                >
                  ➤ {editingId !== null ? "Update Entry" : "Submit Entry"}
                </button>
                {editingId !== null && (
                  <button
                    type="button"
                    onClick={resetForm}
                    className="rounded-lg border border-slate-300 px-3 py-2.5 text-xs hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                )}
              </div>
            </form>
          </section>

          {/* FOUR PEAR CATEGORIES */}
          {categories.map(renderCategorySection)}
        </div>
      </main>
    </div>
  );
}
