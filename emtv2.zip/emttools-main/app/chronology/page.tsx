
"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

type Incident = {
  id: string;
  incident_name: string;
  incident_type: string | null;
  location: string | null;
  incident_date: string | null;
  incident_time?: string | null;
  fire_type: string | null;
  description: string | null;
  status: string;
  created_at: string;
};

type Chronology = {
  id: number;
  incidentId: string;
  incidentName: string;
  information: string;
  categories: string[];
  date: string;
  time: string;
};

const pearOptions = [
  { label: "People", icon: "👥" },
  { label: "Environment", icon: "🌿" },
  { label: "Asset", icon: "⚙️" },
  { label: "Reputation", icon: "⭐" },
];

const menuItems = [
  { label: "Dashboard", href: "/dashboard", icon: "⌂" },
  { label: "Incidents", href: "/incident", icon: "▤" },
  { label: "Chronology", href: "/chronology", icon: "◷" },
  { label: "IP Status", href: "/ipstatus", icon: "▣" },
  { label: "PEAR", href: "/pear", icon: "♧" },
];

async function readApiResponse(response: Response) {
  const text = await response.text();
  let data: any;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    console.error("Chronology API returned non-JSON:", text.slice(0, 500));
    throw new Error(`Chronology API returned non-JSON (HTTP ${response.status}). Check the deployed API route.`);
  }
  if (!response.ok) throw new Error(data?.error || `Chronology request failed (HTTP ${response.status}).`);
  return data;
}

export default function ChronologyPage() {
  const [information, setInformation] = useState("");
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [selectedIncidentId, setSelectedIncidentId] = useState("");
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All Categories");
  const [sortOrder, setSortOrder] = useState("Newest First");
  const [records, setRecords] = useState<Chronology[]>([]);
  const [storageLoaded, setStorageLoaded] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function loadData() {
      const incidentIdFromUrl = new URLSearchParams(window.location.search).get("incidentId");

      // Set the requested incident immediately so the page can retain its context
      // even if the Chronology API is temporarily unavailable.
      if (!cancelled && incidentIdFromUrl) {
        setSelectedIncidentId(incidentIdFromUrl);
      }

      try {
        // Load incidents independently from chronology. A 404 from /api/chronology
        // must not prevent the incident list and selected incident from loading.
        const incidentResponse = await fetch("/api/incidents", { cache: "no-store" });
        const incidentResult = await readApiResponse(incidentResponse);

        const loadedIncidents = (
          Array.isArray(incidentResult)
            ? incidentResult
            : incidentResult.incidents ?? []
        ).map((raw: any) => ({
          ...raw,
          id: String(raw.id),
          incident_name: raw.incident_name ?? raw.name ?? "",
          incident_type: raw.incident_type ?? raw.type ?? null,
          incident_date: raw.incident_date ?? raw.date ?? null,
          incident_time: raw.incident_time ?? raw.time ?? null,
          fire_type: raw.fire_type ?? raw.fireType ?? null,
          location: raw.location ?? null,
          description: raw.description ?? null,
          status: raw.status ?? "Active",
        })) as Incident[];

        if (!cancelled) {
          setIncidents(loadedIncidents);
          if (incidentIdFromUrl) {
            setSelectedIncidentId(incidentIdFromUrl);
          } else if (loadedIncidents.length === 1) {
            setSelectedIncidentId(String(loadedIncidents[0].id));
          }
        }

        // Load chronology separately so its failure cannot block incident selection.
        try {
          const chronologyResponse = await fetch("/api/chronology", { cache: "no-store" });
          const chronologyResult = await readApiResponse(chronologyResponse);

          const loadedRecords = (
            Array.isArray(chronologyResult)
              ? chronologyResult
              : chronologyResult.records ?? []
          ).map((raw: any) => ({
            id: raw.id,
            incidentId: String(raw.incident_id ?? raw.incidentId ?? ""),
            incidentName: raw.incident_name ?? raw.incidentName ?? "",
            information: raw.information ?? "",
            categories: Array.isArray(raw.categories) ? raw.categories : [],
            date: raw.date ?? "",
            time: raw.time ?? "",
          })) as Chronology[];

          if (!cancelled) setRecords(loadedRecords);
        } catch (error) {
          console.error("Unable to load Chronology API; incident selection remains available.", error);
          if (!cancelled) {
            alert(
              error instanceof Error
                ? `${error.message} Your incident is still selected, but chronology records cannot load until the API is fixed.`
                : "Chronology API is unavailable. Your incident is still selected."
            );
          }
        }
      } catch (error) {
        console.error("Unable to load incidents", error);
        if (!cancelled) {
          alert(error instanceof Error ? error.message : "Unable to load incidents.");
        }
      } finally {
        if (!cancelled) setStorageLoaded(true);
      }
    }

    void loadData();
    return () => { cancelled = true; };
  }, []);

  const [editingId, setEditingId] = useState<number | null>(null);

  function toggleCategory(category: string) {
    setSelectedCategories((current) =>
      current.includes(category)
        ? current.filter((item) => item !== category)
        : [...current, category]
    );
  }

  function clearForm() {
    setInformation("");
    // Keep the incident selected: this page is opened from that incident's Manage button.
    setSelectedCategories([]);
    setEditingId(null);
  }

  async function submitReport() {
    if (!selectedIncidentId) {
      alert("Please open Chronology from the Manage button on the relevant Incident Information page.");
      return;
    }

    if (!information.trim()) {
      alert("Please enter the incident information.");
      return;
    }

    const selectedIncident = incidents.find((incident) => String(incident.id) === selectedIncidentId);
    if (!selectedIncident) {
      alert("The selected incident could not be found. Please refresh the page.");
      return;
    }

    const now = new Date();
    const date = now.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
    const time = now.toLocaleTimeString("en-GB", {
      hour: "2-digit",
      minute: "2-digit",
    });

    const payload = {
      incident_id: selectedIncident.id,
      incident_name: selectedIncident.incident_name,
      information: information.trim(),
      categories: [...selectedCategories],
      date,
      time,
    };

    try {
      const response = await fetch("/api/chronology", {
        method: editingId !== null ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingId !== null ? { id: editingId, record: payload } : payload),
      });
      const result = await readApiResponse(response);

      const raw = result.record ?? result;
      const saved: Chronology = {
        id: raw.id,
        incidentId: String(raw.incident_id ?? raw.incidentId ?? payload.incident_id),
        incidentName: raw.incident_name ?? raw.incidentName ?? payload.incident_name,
        information: raw.information ?? payload.information,
        categories: Array.isArray(raw.categories) ? raw.categories : payload.categories,
        date: raw.date ?? payload.date,
        time: raw.time ?? payload.time,
      };

      setRecords((current) => editingId !== null
        ? current.map((record) => String(record.id) === String(editingId) ? saved : record)
        : [saved, ...current]);
      clearForm();
    } catch (error) {
      alert(error instanceof Error ? error.message : "Unable to save chronology record.");
    }
  }

  function editRecord(record: Chronology) {
    setEditingId(record.id);
    setSelectedIncidentId(record.incidentId ?? "");
    setInformation(record.information);
    setSelectedCategories([...(record.categories ?? [])]);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function deleteRecord(id: number) {
    if (!confirm("Are you sure you want to delete this report?")) return;

    try {
      const response = await fetch("/api/chronology", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      const result = await readApiResponse(response);

      setRecords((current) => current.filter((record) => String(record.id) !== String(id)));
      if (String(editingId) === String(id)) clearForm();
    } catch (error) {
      alert(error instanceof Error ? error.message : "Unable to delete chronology record.");
    }
  }

  const filteredRecords = records
    .filter((record) => !selectedIncidentId || record.incidentId === selectedIncidentId)
    .filter((record) =>
      record.information.toLowerCase().includes(search.toLowerCase())
    )
    .filter(
      (record) =>
        categoryFilter === "All Categories" ||
        (record.categories ?? []).includes(categoryFilter)
    )
    .sort((a, b) =>
      sortOrder === "Newest First" ? b.id - a.id : a.id - b.id
    );

  return (
    <div className="flex min-h-screen bg-[#edf4fc] text-[#102653]">
      {/* DESKTOP SIDEBAR — kept as the original design */}
      <aside className="hidden w-[220px] shrink-0 flex-col bg-[#102f50] text-white md:flex">
        <div className="border-b border-white/10 px-4 py-5">
          <h1 className="text-lg font-extrabold tracking-wide">
            🚒 EMT SYSTEM
          </h1>
          <p className="mt-1 text-[10px] text-blue-200">
            Emergency Management Team
          </p>
        </div>

        <nav className="space-y-1 p-3">
          {menuItems.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className={`flex items-center gap-3 rounded-lg px-3 py-3 text-sm transition ${
                item.label === "Chronology"
                  ? "bg-blue-500 font-semibold text-white"
                  : "text-blue-100 hover:bg-white/10"
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="mt-auto px-4 py-8 text-center">
          <p className="text-[9px] font-semibold tracking-widest text-blue-200">
            SAFE · PREPARE · RESPOND · RECOVER
          </p>
          <p className="mt-4 text-xs font-medium leading-relaxed">
            &quot;Better Prepared,
            <br />
            Safer Tomorrow&quot;
          </p>
        </div>
      </aside>

      {/* MOBILE SIDEBAR */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <button
            type="button"
            aria-label="Close navigation menu"
            className="absolute inset-0 bg-slate-950/60"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 flex h-full w-[min(82vw,300px)] flex-col bg-[#102f50] text-white shadow-2xl">
            <div className="flex items-start justify-between border-b border-white/10 px-4 py-5">
              <div>
                <h1 className="text-lg font-extrabold tracking-wide">
                  🚒 EMT SYSTEM
                </h1>
                <p className="mt-1 text-[10px] text-blue-200">
                  Emergency Management Team
                </p>
              </div>
              <button
                type="button"
                aria-label="Close navigation menu"
                onClick={() => setMobileMenuOpen(false)}
                className="rounded-lg px-3 py-1 text-2xl text-white hover:bg-white/10"
              >
                ×
              </button>
            </div>
            <nav className="space-y-1 p-3">
              {menuItems.map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-3 rounded-lg px-3 py-3 text-sm transition ${
                    item.label === "Chronology"
                      ? "bg-blue-500 font-semibold text-white"
                      : "text-blue-100 hover:bg-white/10"
                  }`}
                >
                  <span className="text-lg">{item.icon}</span>
                  {item.label}
                </Link>
              ))}
            </nav>
            <div className="mt-auto px-4 py-8 text-center">
              <p className="text-[9px] font-semibold tracking-widest text-blue-200">
                SAFE · PREPARE · RESPOND · RECOVER
              </p>
              <p className="mt-4 text-xs font-medium leading-relaxed">
                &quot;Better Prepared,
                <br />
                Safer Tomorrow&quot;
              </p>
            </div>
          </aside>
        </div>
      )}

      {/* MAIN CONTENT */}
      <main className="min-w-0 flex-1">
        {/* HEADER */}
        <header className="flex min-h-[76px] flex-wrap items-center justify-between gap-3 border-b border-blue-100 bg-gradient-to-r from-blue-50 via-sky-100 to-white px-4 py-4 sm:px-7">
          <div className="flex min-w-0 items-center gap-3">
            <button
              type="button"
              aria-label="Open navigation menu"
              aria-expanded={mobileMenuOpen}
              onClick={() => setMobileMenuOpen(true)}
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-blue-200 bg-white text-xl text-[#17365d] shadow-sm hover:bg-blue-50 md:hidden"
            >
              ☰
            </button>
            <div>
            <h2 className="text-xl font-bold text-[#15365f]">
              Chronology Management
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              Manage incident chronology reports
            </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/dashboard"
              className="rounded-lg border border-blue-200 bg-white px-3 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-50"
            >
              ← Dashboard
            </Link>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-100 font-bold text-blue-800">
              U
            </div>
          </div>
        </header>

        <div className="space-y-5 p-4 sm:p-7">
          {/* ADD CHRONOLOGY */}
          <section className="rounded-xl border border-blue-100 bg-white p-5 shadow-sm">
            <div className="mb-5 flex items-center gap-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-500 text-xl text-white">
                {editingId !== null ? "✎" : "+"}
              </span>
              <div>
                <h3 className="font-bold text-[#17365d]">
                  {editingId !== null
                    ? "Edit Chronology Report"
                    : "Add New Chronology Report"}
                </h3>
                <p className="mt-1 text-xs text-slate-500">
                  Record incident developments and their PEAR categories
                </p>
              </div>
            </div>

            <form
              onSubmit={(event) => {
                event.preventDefault();
                submitReport();
              }}
              className="space-y-5"
            >
              <div className="rounded-lg border border-blue-100 bg-blue-50/70 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-blue-700">Selected Incident</p>
                {(() => {
                  const activeIncident = incidents.find((incident) => incident.id === selectedIncidentId);
                  return activeIncident ? (
                    <>
                      <p className="mt-1 font-bold text-[#17365d]">{activeIncident.incident_name}</p>
                      <p className="mt-1 text-xs text-slate-600">
                        {activeIncident.incident_type || "Type not set"} · {activeIncident.location || "Location not set"}
                      </p>
                    </>
                  ) : (
                    <p className="mt-1 text-sm text-amber-700">
                      No incident selected. Open this page using Manage from the relevant Incident Information page.
                    </p>
                  );
                })()}
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold">
                  Incident Information{" "}
                  <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={information}
                  onChange={(event) => setInformation(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" && !event.shiftKey) {
                      event.preventDefault();
                      submitReport();
                    }
                  }}
                  placeholder="Type chronology and press Enter to submit. Use Shift + Enter for a new line."
                  rows={4}
                  required
                  className="w-full rounded-lg border border-blue-200 bg-white p-4 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                />
              </div>

              <div>
                <p className="mb-3 text-sm font-semibold">
                  PEAR Categories{" "}
                  <span className="font-normal text-slate-400">
                    (Optional)
                  </span>
                </p>

                <div className="flex flex-wrap gap-2">
                  {pearOptions.map((option) => {
                    const checked = selectedCategories.includes(option.label);

                    return (
                      <button
                        type="button"
                        key={option.label}
                        onClick={() => toggleCategory(option.label)}
                        aria-pressed={checked}
                        className={`rounded-lg border px-4 py-2.5 text-sm transition ${
                          checked
                            ? "border-blue-500 bg-blue-50 font-semibold text-blue-700"
                            : "border-blue-100 bg-white hover:bg-blue-50"
                        }`}
                      >
                        <span className="mr-2">{option.icon}</span>
                        {option.label}
                        {checked ? " ✓" : ""}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex flex-wrap justify-end gap-3 border-t border-slate-100 pt-4">
                <button
                  type="button"
                  onClick={clearForm}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-5 py-2.5 text-sm font-semibold hover:bg-slate-100"
                >
                  Clear
                </button>

                {editingId !== null && (
                  <button
                    type="button"
                    onClick={clearForm}
                    className="rounded-lg border border-slate-200 px-5 py-2.5 text-sm font-semibold hover:bg-slate-50"
                  >
                    Cancel Edit
                  </button>
                )}

                <button
                  type="submit"
                  className="rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm hover:bg-blue-700"
                >
                  ➤ {editingId !== null ? "Update Report" : "Submit Report"}
                </button>
              </div>
            </form>
          </section>

          {/* CHRONOLOGY RECORDS */}
          <section className="rounded-xl border border-blue-100 bg-white p-5 shadow-sm">
            <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-center">
              <div>
                <h3 className="font-bold text-[#17365d]">
                  ◷ Chronology Reports
                </h3>
                <p className="mt-1 text-xs text-slate-500">
                  Search, review and manage chronology records
                </p>
              </div>

              <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                <input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Search reports..."
                  className="rounded-lg border border-blue-100 px-3 py-2.5 text-sm outline-none focus:border-blue-500"
                />

                <select
                  value={categoryFilter}
                  onChange={(event) => setCategoryFilter(event.target.value)}
                  className="rounded-lg border border-blue-100 bg-white px-3 py-2.5 text-sm"
                >
                  <option>All Categories</option>
                  {pearOptions.map((option) => (
                    <option key={option.label} value={option.label}>
                      {option.label}
                    </option>
                  ))}
                </select>

                <select
                  value={sortOrder}
                  onChange={(event) => setSortOrder(event.target.value)}
                  className="rounded-lg border border-blue-100 bg-white px-3 py-2.5 text-sm"
                >
                  <option>Newest First</option>
                  <option>Oldest First</option>
                </select>
              </div>
            </div>

            <div className="mt-5 overflow-x-auto">
              <table className="w-full min-w-[650px] text-left text-sm">
                <thead className="bg-[#eaf3ff] text-[#25466f]">
                  <tr>
                    {[
                      "Last Updated",
                      "Incident",
                      "Information",
                      "PEAR Categories",
                      "Actions",
                    ].map((heading) => (
                      <th key={heading} className="px-4 py-3 font-semibold">
                        {heading}
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody>
                  {filteredRecords.map((record) => (
                    <tr
                      key={record.id}
                      className="border-b border-blue-50 hover:bg-blue-50/50"
                    >
                      <td className="whitespace-nowrap px-4 py-3">
                        {record.date}
                        <p className="mt-1 text-xs text-slate-500">
                          {record.time}
                        </p>
                      </td>

                      <td className="px-4 py-3">
                        <span className="font-semibold text-[#17365d]">
                          {record.incidentName || "Unlinked incident"}
                        </span>
                      </td>

                      <td className="max-w-md whitespace-pre-wrap px-4 py-3">
                        {record.information}
                      </td>

                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          {(record.categories ?? []).length ? (
                            (record.categories ?? []).map((category) => (
                              <span
                                key={category}
                                className="rounded-full bg-blue-50 px-2 py-1 text-xs text-blue-700"
                              >
                                {category}
                              </span>
                            ))
                          ) : (
                            <span className="text-slate-400">—</span>
                          )}
                        </div>
                      </td>

                      <td className="px-4 py-3">
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => editRecord(record)}
                            className="rounded-lg bg-blue-50 px-3 py-2 text-blue-700 hover:bg-blue-100"
                            aria-label="Edit chronology report"
                            title="Edit"
                          >
                            ✎
                          </button>

                          <button
                            type="button"
                            onClick={() => deleteRecord(record.id)}
                            className="rounded-lg bg-red-50 px-3 py-2 text-red-600 hover:bg-red-100"
                            aria-label="Delete chronology report"
                            title="Delete"
                          >
                            🗑
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {filteredRecords.length === 0 && (
                <div className="px-4 py-12 text-center">
                  <div className="text-3xl text-blue-300">◷</div>
                  <p className="mt-3 font-semibold text-slate-500">
                    No chronology reports available
                  </p>
                  <p className="mt-1 text-sm text-slate-400">
                    Submit a report using the form above.
                  </p>
                </div>
              )}
            </div>

            <div className="mt-4 border-t border-blue-50 pt-4 text-xs text-slate-500">
              Showing {filteredRecords.length} of {records.filter((record) => !selectedIncidentId || record.incidentId === selectedIncidentId).length} records for this incident
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
