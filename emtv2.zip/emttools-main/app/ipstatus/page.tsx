
"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

type Incident = {
  id: string;
  incident_name: string;
  incident_type: string | null;
  location: string | null;
  incident_date: string | null;
  incident_time?: string | null;
  fire_type: string | null;
  description: string | null;
  status: string;
  created_at: string;
};

type IPRecord = {
  id: number;
  incidentId: string;
  incidentName: string;
  reportedBy: string;
  ipId: string;
  status: string;
  location: string;
  information: string;
  updatedAt: string;
};

export default function IPStatusPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [records, setRecords] = useState<IPRecord[]>([]);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [selectedIncidentId, setSelectedIncidentId] = useState("");
  const [storageReady, setStorageReady] = useState(false);

  useEffect(() => {
    try {
      const savedIncidents = window.localStorage.getItem("emt_incidents");
      const parsedIncidents: unknown = savedIncidents ? JSON.parse(savedIncidents) : [];
      const loadedIncidents = Array.isArray(parsedIncidents) ? parsedIncidents as Incident[] : [];
      setIncidents(loadedIncidents);
      const incidentIdFromUrl = new URLSearchParams(window.location.search).get("incidentId") || "";
      setSelectedIncidentId(incidentIdFromUrl);

      const savedRecords = window.localStorage.getItem("emt_ip_status");
      const parsedRecords: unknown = savedRecords ? JSON.parse(savedRecords) : [];
      setRecords(Array.isArray(parsedRecords) ? parsedRecords as IPRecord[] : []);
    } catch {
      alert("Unable to load saved IP status records from this browser.");
    } finally {
      setStorageReady(true);
    }
  }, []);

  useEffect(() => {
    if (storageReady) {
      window.localStorage.setItem("emt_ip_status", JSON.stringify(records));
    }
  }, [records, storageReady]);
  const [reportedBy, setReportedBy] = useState("");
  const [ipId, setIpId] = useState("");
  const [status, setStatus] = useState("");
  const [location, setLocation] = useState("");
  const [information, setInformation] = useState("");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("newest");
  const [editingId, setEditingId] = useState<number | null>(null);

  function resetForm() {
    // Keep the incident selected by the Incident Information page.
    setIpId("");
    setStatus("");
    setLocation("");
    setInformation("");
    setEditingId(null);
  }

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    if (!selectedIncidentId) {
      alert("No incident selected. Open IP Status using Manage from the relevant Incident Information page.");
      return;
    }
    if (!reportedBy.trim() || !ipId.trim() || !status || !location.trim()) {
      alert("Please complete all required fields.");
      return;
    }

    const selectedIncident = incidents.find((incident) => incident.id === selectedIncidentId);
    if (!selectedIncident) {
      alert("Selected incident was not found. Please refresh the page.");
      return;
    }

    const record: IPRecord = {
      id: editingId ?? Date.now(),
      incidentId: selectedIncident.id,
      incidentName: selectedIncident.incident_name,
      reportedBy: reportedBy.trim(),
      ipId: ipId.trim(),
      status,
      location: location.trim(),
      information: information.trim(),
      updatedAt: new Date().toLocaleString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }),
    };

    if (editingId !== null) {
      setRecords((previous) =>
        previous.map((item) => item.id === editingId ? record : item)
      );
    } else {
      setRecords((previous) => [record, ...previous]);
    }

    resetForm();
  }

  function handleEdit(record: IPRecord) {
    if (record.incidentId !== selectedIncidentId) return;
    setEditingId(record.id);
    setReportedBy(record.reportedBy);
    setIpId(record.ipId);
    setStatus(record.status);
    setLocation(record.location);
    setInformation(record.information);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleDelete(id: number) {
    if (confirm("Delete this IP status record?")) {
      setRecords((previous) => previous.filter((item) => item.id !== id));
    }
  }

  const filteredRecords = records
    .filter((record) => record.incidentId === selectedIncidentId)
    .filter((record) =>
      [
        record.incidentName || "",
        record.reportedBy,
        record.ipId,
        record.status,
        record.location,
        record.information,
      ].some((value) => value.toLowerCase().includes(search.toLowerCase()))
    )
    .sort((a, b) =>
      sort === "newest"
        ? b.id - a.id
        : a.id - b.id
    );

  const inputClass =
    "w-full rounded-md border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100";

  const labelClass = "mb-1.5 block text-xs font-semibold text-slate-700";

  return (
    <div className="flex min-h-screen bg-[#edf5ff] text-slate-800">
      <aside className="relative hidden w-[220px] shrink-0 flex-col overflow-hidden bg-[#102f50] text-white md:flex">
        <div className="relative z-10 flex items-center gap-3 border-b border-white/10 px-4 py-5">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white text-xl">
            🚒
          </div>
          <div>
            <h1 className="text-lg font-extrabold tracking-wide">EMT SYSTEM</h1>
            <p className="text-[10px] text-blue-200">
              Emergency Management Team
            </p>
          </div>
        </div>

        <nav className="relative z-10 space-y-1 p-3 text-sm">
          {[
            { label: "Dashboard", href: "/dashboard", icon: "⌂" },
            { label: "Incidents", href: "/dashboard", icon: "▤" },
            { label: "Chronology", href: "/chronology", icon: "◷" },
            { label: "IP Status", href: "/ipstatus", icon: "▣" },
            { label: "PEAR", href: "/pear", icon: "♟" },
          ].map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className={`flex items-center gap-3 rounded-md px-3 py-3 transition ${
                item.label === "IP Status"
                  ? "bg-blue-500 font-semibold text-white"
                  : "text-blue-100 hover:bg-white/10"
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-orange-950/70 via-blue-950/20 to-transparent" />

        <div className="relative z-10 mt-auto p-5 text-center">
          <p className="text-[9px] font-semibold tracking-widest text-blue-200">
            SAFE · PREPARE · RESPOND · RECOVER
          </p>
          <p className="mt-4 text-xs font-medium leading-relaxed">
            &quot;Better Prepared,
            <br />
            Safer Tomorrow&quot;
          </p>
        </div>
      </aside>

      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <button
            type="button"
            aria-label="Close navigation"
            className="absolute inset-0 bg-slate-950/60"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 flex h-full w-[280px] max-w-[85vw] flex-col overflow-hidden bg-[#102f50] text-white shadow-2xl">
            <div className="flex items-center justify-between gap-3 border-b border-white/10 px-4 py-5">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white text-xl">🚒</div>
                <div>
                  <h1 className="text-lg font-extrabold tracking-wide">EMT SYSTEM</h1>
                  <p className="text-[10px] text-blue-200">Emergency Management Team</p>
                </div>
              </div>
              <button
                type="button"
                className="rounded-md px-2 py-1 text-xl text-white hover:bg-white/10"
                aria-label="Close navigation"
                onClick={() => setMobileMenuOpen(false)}
              >
                ×
              </button>
            </div>
            <nav className="space-y-1 p-3 text-sm">
              {[
                { label: "Dashboard", href: "/dashboard", icon: "⌂" },
                { label: "Incidents", href: "/dashboard", icon: "▤" },
                { label: "Chronology", href: "/chronology", icon: "◷" },
                { label: "IP Status", href: "/ipstatus", icon: "▣" },
                { label: "PEAR", href: "/pear", icon: "♟" },
              ].map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-3 rounded-md px-3 py-3 transition ${
                    item.label === "IP Status"
                      ? "bg-blue-500 font-semibold text-white"
                      : "text-blue-100 hover:bg-white/10"
                  }`}
                >
                  <span className="text-lg">{item.icon}</span>
                  {item.label}
                </Link>
              ))}
            </nav>
            <div className="mt-auto p-5 text-center">
              <p className="text-[9px] font-semibold tracking-widest text-blue-200">SAFE · PREPARE · RESPOND · RECOVER</p>
              <p className="mt-4 text-xs font-medium leading-relaxed">&quot;Better Prepared,<br />Safer Tomorrow&quot;</p>
            </div>
          </aside>
        </div>
      )}

      <main className="min-w-0 flex-1">
        <header className="relative flex min-h-[76px] items-center justify-between gap-3 overflow-hidden border-b border-blue-100 bg-white px-4 py-3 sm:px-7">
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-blue-50 via-sky-100 to-white" />

          <div className="relative flex items-center gap-3">
            <button
              type="button"
              className="rounded-md px-2 py-1 text-xl hover:bg-blue-100 md:hidden"
              aria-label="Open navigation"
              onClick={() => setMobileMenuOpen(true)}
            >
              ☰
            </button>
            <div>
              <h2 className="text-xl font-bold text-[#15365f]">
                IP Status Management
              </h2>
              <p className="text-xs text-slate-500">
                Manage incident IP status records
              </p>
            </div>
          </div>

          <div className="relative flex items-center gap-3">
            <button
              type="button"
              className="relative rounded-full border border-blue-100 bg-white p-2.5"
              aria-label="Notifications"
            >
              ♧
              <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] text-white">
                3
              </span>
            </button>
            <div className="hidden text-right sm:block">
              <p className="text-xs font-bold text-[#17365d]">EMT User</p>
              <p className="text-[10px] text-slate-500">Incident Commander</p>
            </div>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-100 font-bold text-blue-800">
              U
            </div>
          </div>
        </header>

        <div className="mx-auto max-w-[1500px] space-y-4 p-4 sm:p-6">
          <section className="rounded-xl border border-blue-100 bg-white p-4 shadow-sm">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
              <h3 className="flex items-center gap-2 font-bold text-[#17365d]">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-blue-100 text-blue-600">
                  ◉
                </span>
                Selected Incident
              </h3>
              <Link
                href="/dashboard"
                className="rounded-md border border-blue-300 px-3 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-50"
              >
                ← Back to Incident Details
              </Link>
            </div>

            <div className="rounded-lg bg-[#eaf4ff] p-3">
              <p className="font-semibold text-[#17365d]">
                {incidents.find((incident) => incident.id === selectedIncidentId)?.incident_name || "No incident selected"}
              </p>
              <div className="mt-2 flex flex-wrap gap-x-6 gap-y-2 text-xs text-slate-600">
                <span>▦ Date: {incidents.find((incident) => incident.id === selectedIncidentId)?.incident_date || "—"}</span>
                <span>📍 Location: {incidents.find((incident) => incident.id === selectedIncidentId)?.location || "—"}</span>
                <span>✚ Type: {incidents.find((incident) => incident.id === selectedIncidentId)?.incident_type || "—"}</span>
              </div>
              {!selectedIncidentId && (
                <p className="mt-3 text-xs font-medium text-amber-700">
                  No incident selected. Open IP Status using Manage from the relevant Incident Information page.
                </p>
              )}
            </div>
          </section>

          <section className="rounded-xl border border-blue-100 bg-white p-4 shadow-sm">
            <h3 className="mb-4 flex items-center gap-2 font-bold text-[#17365d]">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-blue-500 text-lg text-white">
                {editingId !== null ? "✎" : "+"}
              </span>
              {editingId !== null ? "Edit IP Record" : "Add New IP Record"}
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div>
                  <label className={labelClass}>
                    Reported By <span className="text-red-500">*</span>
                  </label>
                  <input
                    className={inputClass}
                    value={reportedBy}
                    onChange={(e) => setReportedBy(e.target.value)}
                    placeholder="Enter reporter name"
                    required
                  />
                </div>

                <div>
                  <label className={labelClass}>
                    IP ID <span className="text-red-500">*</span>
                  </label>
                  <input
                    className={inputClass}
                    value={ipId}
                    onChange={(e) => setIpId(e.target.value)}
                    placeholder="Enter IP ID"
                    required
                  />
                </div>

                <div>
                  <label className={labelClass}>
                    IP Status <span className="text-red-500">*</span>
                  </label>
                  <select
                    className={inputClass}
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    required
                  >
                    <option value="">Select IP status</option>
                    <option value="Active">Active</option>
                    <option value="Standby">Standby</option>
                    <option value="Under Treatment">Under Treatment</option>
                    <option value="Transported">Transported</option>
                    <option value="Discharged">Discharged</option>
                    <option value="Deceased">Deceased</option>
                    <option value="Unknown">Unknown</option>
                  </select>
                </div>

                <div>
                  <label className={labelClass}>
                    Location <span className="text-red-500">*</span>
                  </label>
                  <input
                    className={inputClass}
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Enter incident location"
                    required
                  />
                </div>
              </div>

              <div>
                <label className={labelClass}>Info Incident</label>
                <textarea
                  className={inputClass}
                  rows={3}
                  value={information}
                  onChange={(e) => setInformation(e.target.value)}
                  placeholder="Enter incident information"
                />
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  type="submit"
                  className="rounded-md bg-blue-500 px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-blue-600"
                >
                  ➤ {editingId !== null ? "Update IP Record" : "Submit IP Record"}
                </button>

                {editingId !== null && (
                  <button
                    type="button"
                    onClick={resetForm}
                    className="rounded-md border border-slate-300 px-4 py-2.5 text-xs font-semibold hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                )}
              </div>
            </form>
          </section>

          <section className="overflow-hidden rounded-xl border border-blue-100 bg-white p-4 shadow-sm">
            <div className="mb-4 flex flex-col justify-between gap-3 lg:flex-row lg:items-center">
              <h3 className="flex items-center gap-2 font-bold text-[#17365d]">
                <span className="flex h-7 w-7 items-center justify-center rounded-md bg-blue-100 text-blue-600">
                  ▦
                </span>
                IP Status Records
              </h3>

              <div className="flex flex-col gap-2 sm:flex-row">
                <input
                  className={`${inputClass} sm:w-56`}
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="⌕ Search IP records..."
                />
                <select
                  className={`${inputClass} sm:w-36`}
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                >
                  <option value="newest">Newest First</option>
                  <option value="oldest">Oldest First</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full min-w-[800px] border-collapse text-left text-xs">
                <thead>
                  <tr className="bg-[#eaf3ff] text-[#25466f]">
                    {[
                      "Incident",
                      "Last Updated",
                      "Reported By",
                      "IP ID",
                      "IP Status",
                      "Location",
                      "Info Incident",
                      "Actions",
                    ].map((heading) => (
                      <th key={heading} className="px-3 py-3 font-semibold">
                        {heading}
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody>
                  {filteredRecords.map((record) => (
                    <tr
                      key={record.id}
                      className="border-b border-slate-100 hover:bg-blue-50/50"
                    >
                      <td className="px-3 py-3 font-semibold text-blue-800">
                        {record.incidentName || "Unlinked incident"}
                      </td>
                      <td className="px-3 py-3 text-slate-500">
                        {record.updatedAt}
                      </td>
                      <td className="px-3 py-3">{record.reportedBy}</td>
                      <td className="px-3 py-3 font-semibold">{record.ipId}</td>
                      <td className="px-3 py-3">
                        <span
                          className={`rounded-md px-2.5 py-1 font-semibold ${
                            record.status === "Active"
                              ? "bg-emerald-100 text-emerald-700"
                              : record.status === "Standby"
                                ? "bg-blue-100 text-blue-700"
                                : "bg-amber-100 text-amber-700"
                          }`}
                        >
                          {record.status}
                        </span>
                      </td>
                      <td className="px-3 py-3">{record.location}</td>
                      <td className="max-w-xs px-3 py-3">{record.information || "—"}</td>
                      <td className="px-3 py-3">
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => handleEdit(record)}
                            className="rounded-md bg-blue-100 px-2.5 py-1.5 text-blue-700 hover:bg-blue-200"
                            aria-label="Edit IP record"
                          >
                            ✎
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(record.id)}
                            className="rounded-md bg-red-100 px-2.5 py-1.5 text-red-700 hover:bg-red-200"
                            aria-label="Delete IP record"
                          >
                            🗑
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}

                  {filteredRecords.length === 0 && (
                    <tr>
                      <td colSpan={8} className="px-3 py-12 text-center">
                        <div className="text-2xl text-slate-300">▤</div>
                        <p className="mt-2 font-semibold text-slate-600">
                          No IP status records
                        </p>
                        <p className="mt-1 text-slate-400">
                          {search
                            ? "Try a different search term."
                            : "Submit a new IP record using the form above."}
                        </p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
              <span>Showing {filteredRecords.length} of {records.length} records</span>
              <span>{selectedIncidentId ? "Records for selected incident" : "No incident selected"}</span>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
